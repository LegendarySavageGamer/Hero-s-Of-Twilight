

#include "mod.hpp"
#include "net/messages.hpp"
#include "print.hpp"
#include "util.hpp"
#include "global/global_client.hpp"

#include "mods/service.hpp"
#include "mods/svc/config.h"
#include "mods/svc/host.h"
#include "mods/svc/http.h"
#include "mods/svc/file.h"
#include "mods/svc/ui.h"

#include "d/actor/d_a_alink.h"
#include "d/d_com_inf_game.h"

#include <chrono>
#include <cstdio>
#include <cstring>
#include <deque>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <string>
#include <vector>
#include <algorithm>

#if defined(__ANDROID__)
#include <sys/system_properties.h>
#endif
#if defined(__APPLE__) || defined(__linux__)
#include <sys/utsname.h>
#endif
#if defined(__APPLE__)
#include <TargetConditionals.h>
#endif

extern const ConfigService* svc_config;
extern const HostService* svc_host;

IMPORT_OPTIONAL_SERVICE(HttpService, svc_http);
IMPORT_OPTIONAL_SERVICE(FileService, svc_file);
extern const UiService* svc_ui;

namespace {

const char* const kReportUrl = "https://crests-rooms.twilight-heroes.workers.dev/report";
const char* const kReportMediaUrl = "https://crests-rooms.twilight-heroes.workers.dev/report-media";

std::mutex s_logMutex;
std::deque<std::string> s_lines;
size_t s_lineBytes = 0;
const size_t kKeepBytes = 400u * 1024u;
std::string s_unwritten;
const auto s_start = std::chrono::steady_clock::now();

std::filesystem::path log_dir() {
    const char* dir = nullptr;
    if (svc_host == nullptr || svc_host->data_dir(mod_ctx, &dir) != MOD_OK || dir == nullptr) return {};
    return std::filesystem::u8path(dir);
}

std::string current_log() {
    std::lock_guard lock(s_logMutex);
    std::string out;
    out.reserve(s_lineBytes);
    for (const std::string& line : s_lines) out += line;
    return out;
}

std::string previous_log(int back = 1, size_t keep = kKeepBytes) {
    std::ifstream in(log_dir() / ("coop-log-" + std::to_string(back) + ".txt"), std::ios::binary);
    if (!in) return "(no log from that run)\n";
    std::string all((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    if (all.size() > keep) all.erase(0, all.size() - keep);
    return all;
}

std::string crash_trail_tail(size_t keep = 16u * 1024u) {
    std::ifstream in("coop-crash-trail.txt", std::ios::binary);
    if (!in) return "(no crash trail)\n";
    std::string all((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    if (all.size() > keep) {
        all.erase(0, all.size() - keep);
        const size_t nl = all.find('\n');
        if (nl != std::string::npos) all.erase(0, nl + 1);
    }
    return all;
}

std::string engine_log_before(size_t keep = 48u * 1024u) {
    const std::filesystem::path data = log_dir();
    if (data.empty()) return "(no engine log)\n";
    std::error_code ec;
    const std::filesystem::path logs = data.parent_path().parent_path() / "logs";
    std::vector<std::filesystem::path> runs;
    for (const auto& e : std::filesystem::directory_iterator(logs, ec)) {
        const std::string name = path_text(e.path().filename());
        if (name.rfind("dusklight-", 0) == 0 && e.path().extension() == ".log") runs.push_back(e.path());
    }
    if (runs.size() < 2) return "(no engine log from that run)\n";
    std::sort(runs.begin(), runs.end());
    std::ifstream in(runs[runs.size() - 2], std::ios::binary);
    if (!in) return "(no engine log from that run)\n";
    std::string out;
    std::string line;
    while (std::getline(in, line)) {
        if (line.find("Loading Resource") != std::string::npos) continue;
        out += line;
        out += '\n';
        if (out.size() > 4 * keep) out.erase(0, out.size() - keep);
    }
    if (out.size() > keep) out.erase(0, out.size() - keep);
    return out;
}

std::ofstream s_file;
size_t s_fileBytes = 0;
const size_t kFileCap = 2u * 1024u * 1024u;

void flush_to_disk() {
    std::string chunk;
    {
        std::lock_guard lock(s_logMutex);
        if (s_unwritten.empty()) return;
        chunk.swap(s_unwritten);
    }
    const std::filesystem::path dir = log_dir();
    if (dir.empty()) return;
    if (s_file.is_open() && s_fileBytes > kFileCap) s_file.close();
    if (!s_file.is_open()) {
        const bool first = s_fileBytes == 0;
        s_file.open(dir / "coop-log.txt", std::ios::binary | std::ios::trunc);
        if (!s_file) return;
        s_fileBytes = 0;
        if (!first) chunk = current_log();
    }
    s_file << chunk;
    s_file.flush();
    s_fileBytes += chunk.size();
}

std::string platform_name() {
#if defined(_WIN32)
    return "windows";
#elif defined(__ANDROID__)
    return "android";
#elif defined(__APPLE__) && TARGET_OS_IOS
    return "ios";
#elif defined(__APPLE__)
    return "macos";
#elif defined(__linux__)
    return "linux";
#else
    return "unknown";
#endif
}

std::string device_name() {
#if defined(__ANDROID__)
    char maker[PROP_VALUE_MAX] = {}, model[PROP_VALUE_MAX] = {}, release[PROP_VALUE_MAX] = {};
    __system_property_get("ro.product.manufacturer", maker);
    __system_property_get("ro.product.model", model);
    __system_property_get("ro.build.version.release", release);
    return std::string(maker) + " " + model + ", Android " + release;
#elif defined(__APPLE__) || defined(__linux__)
    struct utsname u {};
    if (uname(&u) != 0) return "";
    std::string out = std::string(u.machine) + ", " + u.sysname + " " + u.release;
#if defined(__linux__)
    std::ifstream os("/etc/os-release");
    std::string line;
    while (std::getline(os, line)) {
        if (line.rfind("PRETTY_NAME=", 0) == 0) {
            std::string name = line.substr(12);
            if (name.size() >= 2 && name.front() == '"') name = name.substr(1, name.size() - 2);
            out += " (" + name + ")";
            break;
        }
    }
#endif
    return out;
#else
    return "";
#endif
}

std::string session_summary() {
    std::string s;
    s += "role: ";
    s += !coop_net_connected() ? "not connected" : coop_net_is_host() ? "host" : "joiner";
    s += "\nplayer id: " + std::to_string(coop_net_local_id());
    const std::string code = online_room_code();
    if (!code.empty()) s += "\nroom code: yes";
    const char* stage = dComIfGp_getStartStageName();
    s += "\nstage: ";
    s += (stage != nullptr && stage[0] != '\0') ? stage : "(none)";
    if (daAlink_getAlinkActorClass() != nullptr) {
        s += " room " + std::to_string(dComIfGp_roomControl_getStayNo());
    }
    s += "\nmode: ";
    s += global_client_connected() ? "Hyrule Online" : coop_net_connected() ? "Twilight Connected" : "not connected";
    if (coop_net_connected()) {
        s += "\nstory sync: "; s += coop_session(kSessStory, cfg_bool(world_story_var(), false)) ? "on" : "off";
        s += "\nenemy sync: "; s += coop_session(kSessEnemies, cfg_bool(enemies_enabled_var(), false)) ? "on" : "off";
        s += "\nboss sync: "; s += coop_session(kSessBosses, cfg_bool(boss_enabled_var(), false)) ? "on" : "off";
    } else if (global_client_connected()) {
        s += "\nstory sync: off (Hyrule Online independent adventure)";
        s += "\nenemy sync: off (Hyrule Online independent adventure)";
        s += "\nboss sync: off (Hyrule Online independent adventure)";
    }
    if (daAlink_getAlinkActorClass() != nullptr) {
        s += "\nform: ";
        s += daAlink_getAlinkActorClass()->checkWolf() ? "wolf" : "human";
    }
    s += "\nrandomizer: ";
    s += rando_active() ? "yes" : "no";
    s += "\nmemory: " + coop_mem_status();

    s += "\nmodels:";
    bool anyModel = false;
    for (int slot = 0; slot < kSkinChoiceCount; ++slot) {
        const std::string chosen = skins_local_slot(slot);
        if (chosen.empty()) continue;
        s += std::string(anyModel ? ", " : " ") + skins_slot_label(slot) + "=" + chosen;
        anyModel = true;
    }
    if (!anyModel) s += " (all the game's own)";
    s += "\nplayers:";
    for (int i = 0; i < kCoopMaxPlayers; ++i) {
        const uint8_t id = static_cast<uint8_t>(i);
        if (id == coop_net_local_id() || !coop_net_player_present(id)) continue;
        const CoopPeer& p = features_peer_of(id);
        char line[160];
        std::snprintf(line, sizeof(line), "\n  %d '%s' stage=%.8s inGame=%d%s", i, p.name.c_str(),
            p.stage, p.inGame ? 1 : 0, coop_player_unheard(id) ? " NO SIGNAL" : "");
        s += line;
    }
    return s;
}

std::string json_escape(const std::string& in) {
    std::string out;
    out.reserve(in.size() + in.size() / 16 + 2);
    for (unsigned char c : in) {
        switch (c) {
        case '"': out += "\\\""; break;
        case '\\': out += "\\\\"; break;
        case '\n': out += "\\n"; break;
        case '\r': break;
        case '\t': out += "\\t"; break;
        default:
            if (c < 0x20) {
                char buf[8];
                std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                out += buf;
            } else {
                out.push_back(static_cast<char>(c));
            }
        }
    }
    return out;
}

std::string scrub_addresses(std::string text) {
    std::string out;
    out.reserve(text.size());
    size_t i = 0;
    while (i < text.size()) {

        size_t j = i;
        int parts = 0;
        while (parts < 4) {
            size_t k = j;
            while (k < text.size() && k - j < 4 && text[k] >= '0' && text[k] <= '9') ++k;
            if (k == j || k - j > 3) break;
            ++parts;
            j = k;
            if (parts < 4) {
                if (j < text.size() && text[j] == '.') ++j;
                else break;
            }
        }
        const bool boundary = i == 0 || !(text[i - 1] >= '0' && text[i - 1] <= '9');
        if (parts == 4 && boundary) {
            out += "x.x.x.x";
            i = j;
        } else {
            out.push_back(text[i++]);
        }
    }
    return out;
}

std::string build_body(const char* kind, const std::string& code, const std::string& text,
    const std::string& when, const std::string& log, const std::string& category = "",
    const std::string& title = "", const std::string& before = "", const std::string& reproduce = "") {
    std::string b = "{";
    b += "\"kind\":\"" + std::string(kind) + "\"";
    if (!code.empty()) b += ",\"code\":\"" + json_escape(code) + "\"";
    b += ",\"player\":\"" + json_escape(features_local_name()) + "\"";
    b += ",\"platform\":\"" + platform_name() + "\"";
    b += ",\"mod\":\"" COOP_MOD_VERSION "\"";
    b += ",\"category\":\"" + json_escape(category) + "\"";
    b += ",\"title\":\"" + json_escape(title) + "\"";
    b += ",\"reproduce\":\"" + json_escape(reproduce) + "\"";
    b += ",\"before\":\"" + json_escape(before) + "\"";
    b += ",\"when\":\"" + json_escape(when) + "\"";
    b += ",\"text\":\"" + json_escape(text) + "\"";
    b += ",\"session\":\"" + json_escape(scrub_addresses(session_summary())) + "\"";
    const std::string state = "=== save state ===\n" + world_state_dump() + "=== end save state ===\n";
    b += ",\"log\":\"" + json_escape(state + scrub_addresses(log)) + "\"";
    b += "}";
    return b;
}

std::string s_text;
std::string s_title;
std::string s_before;
int s_category = 0;
int s_reproduce = 3;
int s_when = 0;
bool s_sending = false;
std::string s_status = "";
uint32_t s_sentAtTick = 0;
uint32_t s_tick = 0;
const char* const kWhen[] = {"Just now", "Earlier this session", "The game crashed or closed last time"};
const char* const kCategories[] = {"Crash", "Twilight Connected", "Hyrule Online", "Story Sync", "Enemy Sync", "Boss Sync", "Player Sync", "Items / Objects", "Death Link", "Randomizer", "Cosmetics / Skins", "UI", "Performance", "Other"};
const char* const kReproduce[] = {"Always", "Sometimes", "Once", "Not Sure"};

std::string s_answered[8];
int s_answeredNext = 0;
std::string s_imageLocation;
std::string s_imageName;
std::string s_videoLocation;
std::string s_videoName;
std::vector<uint8_t> s_mediaUpload;
std::string s_mediaUploadName;
std::string s_mediaUploadCode;
std::string s_mediaUploadKind;

void pick_media_done(ModContext*, ModResult status, const char* const* locations,
    uint32_t location_count, const char*, void* user_data) {
    if (status != MOD_OK || locations == nullptr || location_count == 0 || locations[0] == nullptr) return;
    const bool video = user_data != nullptr;
    std::string location = locations[0];
    char name[256] = {};
    if (svc_file != nullptr && svc_file->display_name != nullptr)
        svc_file->display_name(mod_ctx, location.c_str(), name, sizeof(name));
    if (video) {
        s_videoLocation = std::move(location);
        s_videoName = name[0] != '\0' ? name : "Selected video";
    } else {
        s_imageLocation = std::move(location);
        s_imageName = name[0] != '\0' ? name : "Selected image";
    }
}

void pick_image() {
    if (svc_file == nullptr || svc_file->pick_file == nullptr) { s_status = "Image browser is unavailable on this build."; return; }
    static const FileFilter filters[] = {{"Images", "png;jpg;jpeg"}};
    FilePickOptions options = FILE_PICK_OPTIONS_INIT;
    options.filters = filters; options.filter_count = 1;
    if (svc_file->pick_file(mod_ctx, &options, pick_media_done, nullptr) != MOD_OK)
        s_status = "Could not open the image browser.";
}

void pick_video() {
    if (svc_file == nullptr || svc_file->pick_file == nullptr) { s_status = "Video browser is unavailable on this build."; return; }
    static const FileFilter filters[] = {{"Videos", "mp4;mov"}};
    FilePickOptions options = FILE_PICK_OPTIONS_INIT;
    options.filters = filters; options.filter_count = 1;
    if (svc_file->pick_file(mod_ctx, &options, pick_media_done, reinterpret_cast<void*>(1)) != MOD_OK)
        s_status = "Could not open the video browser.";
}

void upload_next_media(const std::string& code);

void on_media_sent(ModContext*, HttpRequestHandle, const HttpResult* r, void*) {
    const bool ok = r != nullptr && r->error == HTTP_ERROR_NONE && r->status_code == 200;
    const std::string finishedKind = s_mediaUploadKind;
    s_mediaUpload.clear(); s_mediaUploadName.clear(); s_mediaUploadKind.clear();
    if (!ok) {
        s_status = "REPORT SENT — Report ID: " + s_mediaUploadCode + " — " + finishedKind + " attachment could not be uploaded.";
        s_mediaUploadCode.clear();
        return;
    }
    if (finishedKind == "screenshot") s_imageLocation.clear(), s_imageName.clear();
    if (finishedKind == "video") s_videoLocation.clear(), s_videoName.clear();
    const std::string code = s_mediaUploadCode;
    upload_next_media(code);
}

bool upload_location(const std::string& code, const std::string& kind, const std::string& location, size_t maxBytes) {
    if (svc_file == nullptr || svc_http == nullptr || location.empty()) return false;
    FileBuffer file = FILE_BUFFER_INIT;
    if (svc_file->read_all(mod_ctx, location.c_str(), &file) != MOD_OK || file.data == nullptr) return false;
    if (file.size == 0 || file.size > maxBytes) {
        svc_file->free(mod_ctx, &file);
        s_status = kind == "video" ? "REPORT SENT — Video is too large to upload." : "REPORT SENT — Image is too large to upload.";
        return false;
    }
    s_mediaUpload.assign(static_cast<const uint8_t*>(file.data), static_cast<const uint8_t*>(file.data) + file.size);
    svc_file->free(mod_ctx, &file);
    s_mediaUploadCode = code; s_mediaUploadKind = kind;
    static const HttpHeader headers[] = {{"Content-Type", "application/octet-stream"}};
    const std::string url = std::string(kReportMediaUrl) + "?code=" + code + "&kind=" + kind;
    // Keep the URL alive for request() by storing it in the name scratch string until the call returns.
    s_mediaUploadName = url;
    HttpRequestDesc desc = HTTP_REQUEST_DESC_INIT;
    desc.method = HTTP_METHOD_POST; desc.url = s_mediaUploadName.c_str();
    desc.headers = headers; desc.header_count = 1;
    desc.body = s_mediaUpload.data(); desc.body_size = s_mediaUpload.size();
    desc.total_timeout_ms = 120000; desc.max_body_bytes = 64 * 1024;
    HttpRequestHandle handle = 0;
    return svc_http->request(mod_ctx, &desc, on_media_sent, nullptr, &handle) == MOD_OK;
}

void upload_next_media(const std::string& code) {
    if (!s_imageLocation.empty()) {
        if (upload_location(code, "screenshot", s_imageLocation, 10u * 1024u * 1024u)) { s_status = "REPORT SENT — Uploading image... Report ID: " + code; return; }
    }
    if (!s_videoLocation.empty()) {
        if (upload_location(code, "video", s_videoLocation, 50u * 1024u * 1024u)) { s_status = "REPORT SENT — Uploading video... Report ID: " + code; return; }
    }
    s_mediaUploadCode.clear();
    s_status = "REPORT SENT — Thank you for helping improve Heroes of Twilight. Report ID: " + code;
}

std::string code_from(const HttpResult* r) {
    if (r == nullptr || r->body == nullptr) return "";
    const std::string body(static_cast<const char*>(r->body), r->body_size);
    const size_t at = body.find("\"code\":\"");
    if (at == std::string::npos) return "";
    const size_t start = at + 8;
    const size_t end = body.find('"', start);
    if (end == std::string::npos || end - start > 16) return "";
    return body.substr(start, end - start);
}

bool post(const std::string& body, HttpCompleteFn done) {
    if (svc_http == nullptr) return false;
    static const HttpHeader kHeaders[] = {{"Content-Type", "application/json"}};
    HttpRequestDesc desc = HTTP_REQUEST_DESC_INIT;
    desc.method = HTTP_METHOD_POST;
    desc.url = kReportUrl;
    desc.headers = kHeaders;
    desc.header_count = 1;
    desc.body = body.data();
    desc.body_size = body.size();
    desc.total_timeout_ms = 60000;
    desc.max_body_bytes = 64 * 1024;
    HttpRequestHandle handle = 0;
    return svc_http->request(mod_ctx, &desc, done, nullptr, &handle) == MOD_OK;
}

void on_report_sent(ModContext*, HttpRequestHandle, const HttpResult* r, void*) {
    s_sending = false;
    const std::string code = code_from(r);
    const bool accepted = r != nullptr && r->error == HTTP_ERROR_NONE &&
                          (r->status_code == 200 || r->status_code == 202) && !code.empty();
    if (!accepted) {
        const int status = r != nullptr ? r->status_code : 0;
        coop_log::warn("coop_mod: [REPORT] not sent (error {}, status {})",
            r != nullptr ? static_cast<int>(r->error) : -1, status);
        s_status = status == 429 ? "TOO MANY REPORTS — Please try again in a few minutes."
                                 : "REPORT COULD NOT BE SENT — Please try again later.";
        return;
    }
    coop_log::info("coop_mod: [REPORT] sent as {}", code);

    const bool copied = svc_ui != nullptr && SERVICE_HAS(svc_ui, UiService, set_clipboard_text) &&
                        svc_ui->set_clipboard_text != nullptr &&
                        svc_ui->set_clipboard_text(mod_ctx, code.c_str()) == MOD_OK;
    s_status = r->status_code == 202
        ? "REPORT SAVED — Report ID: " + code + " (private delivery is delayed)"
        : "REPORT SUBMITTED — Thank you! Report ID: " + code + (copied ? " (copied)" : "");
    s_text.clear();
    s_title.clear();
    s_before.clear();
    coop_notify_c(kNotifyOther, "Bug report sent",
        ("Report ID: " + code + (copied ? " (copied)" : "")).c_str());

    if (!s_imageLocation.empty() || !s_videoLocation.empty()) upload_next_media(code);

    if (coop_net_connected()) {
        MsgLogRequest req{};
        std::strncpy(req.code, code.c_str(), sizeof(req.code) - 1);
        coop_net_send(kMsgLogRequest, &req, sizeof(req));
    }
}

void on_log_sent(ModContext*, HttpRequestHandle, const HttpResult* r, void*) {
    if (r == nullptr || r->error != HTTP_ERROR_NONE || r->status_code != 200) {
        coop_log::warn("coop_mod: [REPORT] log for peer report not sent");
    }
}

void send_report() {
    if (s_sending || s_text.empty()) return;
    flush_to_disk();
    const bool lastRun = s_when == 2;

    const std::string thisRun = current_log();
    const std::string lastRunLog = previous_log();
    const std::string before = "=== the run before this one ===\n" + lastRunLog;
    const std::string now = "=== this run ===\n" + thisRun;
    std::string log = lastRun ? before + "\n" + now : now + "\n" + before;

    if (lastRun) log += "\n=== two runs before this one ===\n" + previous_log(2, 250u * 1024u);

    log += "\n=== crash trail, last lines ===\n" + crash_trail_tail();
    log += "\n=== dusklight's own log, the run before ===\n" +
           (lastRun ? engine_log_before() : engine_log_before(16u * 1024u));
    const std::string body = build_body("report", "", s_text, kWhen[s_when], log, kCategories[s_category], s_title, s_before, kReproduce[s_reproduce]);
    if (!post(body, on_report_sent)) {
        s_status = "Couldn't send it - this build has no network access.";
        return;
    }
    s_sending = true;
    s_sentAtTick = s_tick;
    s_status = "Sending...";
    coop_log::info("coop_mod: [REPORT] sending ({} KB)", body.size() / 1024);
}

UiElementHandle s_statusElem = 0;
std::string s_statusShown;

}

void coop_log_capture(char level, const std::string& message) {
    const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - s_start).count();
    char head[24];
    std::snprintf(head, sizeof(head), "[%8.1f] %c ", secs, level);
    std::string line = head;
    line += message;
    line += '\n';
    std::lock_guard lock(s_logMutex);
    s_lineBytes += line.size();
    s_unwritten += line;
    s_lines.push_back(std::move(line));
    while (s_lineBytes > kKeepBytes && !s_lines.empty()) {
        s_lineBytes -= s_lines.front().size();
        s_lines.pop_front();
    }
    if (s_unwritten.size() > kKeepBytes) s_unwritten.erase(0, s_unwritten.size() - kKeepBytes);
}

const int kKeepRuns = 3;

void report_init() {

    const std::filesystem::path dir = log_dir();
    if (dir.empty()) return;
    std::error_code ec;
    const auto run = [&](int n) { return dir / ("coop-log-" + std::to_string(n) + ".txt"); };
    std::filesystem::remove(run(kKeepRuns), ec);
    for (int n = kKeepRuns - 1; n >= 1; --n) std::filesystem::rename(run(n), run(n + 1), ec);
    std::filesystem::rename(dir / "coop-log.txt", run(1), ec);
    std::filesystem::remove(dir / "coop-log-previous.txt", ec);
}

void report_update() {
    ++s_tick;

    static char s_stage[8] = {};
    const char* stage = dComIfGp_getStartStageName();
    const bool newStage = stage != nullptr && std::strncmp(stage, s_stage, sizeof(s_stage)) != 0;
    if (newStage) std::strncpy(s_stage, stage, sizeof(s_stage));
    if (newStage || s_tick % 300 == 0) flush_to_disk();
}

void report_on_message(const uint8_t* payload, size_t size, uint8_t from) {
    if (size < sizeof(MsgLogRequest) || from == coop_net_local_id()) return;
    MsgLogRequest req;
    std::memcpy(&req, payload, sizeof(req));
    req.code[sizeof(req.code) - 1] = '\0';
    const std::string code(req.code);
    if (code.size() < 3) return;
    for (const std::string& done : s_answered) {
        if (done == code) return;
    }
    s_answered[s_answeredNext] = code;
    s_answeredNext = (s_answeredNext + 1) % 8;
    flush_to_disk();
    const std::string asker = features_peer_of(from).name;
    const std::string body = build_body("log", code, "log for " + asker + "'s report", "", current_log());
    if (post(body, on_log_sent)) {
        coop_log::info("coop_mod: [REPORT] sending log for {} report {}", asker, code);
    }
}

void report_build_tab(UiElementHandle left, UiElementHandle right) {
    s_statusElem = 0;
    s_statusShown.clear();

    // Support prototype: keep the existing reporting/network logic intact and
    // only reorganize the native Dusklight controls into the two-pane layout.
    svc_ui->pane_add_section(mod_ctx, left, "Telma's Notice Board");
    svc_ui->pane_add_text(mod_ctx, left,
        "Help us improve Heroes of Twilight. Your configured multiplayer name is used as the Reported Username.", nullptr);

    UiControlDesc title = UI_CONTROL_DESC_INIT;
    title.kind = UI_CONTROL_STRING; title.label = "Report Title"; title.binding = UI_BINDING_CALLBACKS;
    title.max_length = 100; title.string_set_mode = UI_STRING_SET_ON_CHANGE;
    title.get = [](ModContext*, void*, UiControlValue* out) { out->string_value = s_title.c_str(); };
    title.set = [](ModContext*, void*, const UiControlValue* v) { s_title = v->string_value != nullptr ? v->string_value : ""; };
    svc_ui->pane_add_control(mod_ctx, left, &title, nullptr);

    UiControlDesc text = UI_CONTROL_DESC_INIT;
    text.kind = UI_CONTROL_STRING; text.label = "What went wrong?"; text.binding = UI_BINDING_CALLBACKS;
    text.max_length = 1500; text.string_set_mode = UI_STRING_SET_ON_CHANGE;
    text.get = [](ModContext*, void*, UiControlValue* out) { out->string_value = s_text.c_str(); };
    text.set = [](ModContext*, void*, const UiControlValue* v) { s_text = v->string_value != nullptr ? v->string_value : ""; };
    text.help_rml = "Explain what went wrong, what you expected, and what actually happened.";
    svc_ui->pane_add_control(mod_ctx, left, &text, nullptr);

    UiControlDesc before = UI_CONTROL_DESC_INIT;
    before.kind = UI_CONTROL_STRING; before.label = "What were you doing?"; before.binding = UI_BINDING_CALLBACKS;
    before.max_length = 1000; before.string_set_mode = UI_STRING_SET_ON_CHANGE;
    before.get = [](ModContext*, void*, UiControlValue* out) { out->string_value = s_before.c_str(); };
    before.set = [](ModContext*, void*, const UiControlValue* v) { s_before = v->string_value != nullptr ? v->string_value : ""; };
    before.help_rml = "Tell us what you were doing immediately before the problem happened.";
    svc_ui->pane_add_control(mod_ctx, left, &before, nullptr);

    UiControlDesc repro = UI_CONTROL_DESC_INIT;
    repro.kind = UI_CONTROL_SELECT; repro.label = "Can it be repeated?"; repro.binding = UI_BINDING_CALLBACKS;
    repro.options = kReproduce; repro.option_count = 4;
    repro.get = [](ModContext*, void*, UiControlValue* out) { out->int_value = s_reproduce; };
    repro.set = [](ModContext*, void*, const UiControlValue* v) { s_reproduce = static_cast<int>(v->int_value); };
    svc_ui->pane_add_control(mod_ctx, left, &repro, nullptr);

    UiControlDesc when = UI_CONTROL_DESC_INIT;
    when.kind = UI_CONTROL_SELECT; when.label = "When did it happen?"; when.binding = UI_BINDING_CALLBACKS;
    when.options = kWhen; when.option_count = 3;
    when.get = [](ModContext*, void*, UiControlValue* out) { out->int_value = s_when; };
    when.set = [](ModContext*, void*, const UiControlValue* v) { s_when = static_cast<int>(v->int_value >= 0 && v->int_value < 3 ? v->int_value : 0); };
    when.help_rml = "For a crash, choose the last option so the previous run's diagnostics are included.";
    svc_ui->pane_add_control(mod_ctx, left, &when, nullptr);

    svc_ui->pane_add_section(mod_ctx, left, "Attachments");
    svc_ui->pane_add_text(mod_ctx, left,
        "Add a screenshot or short video if it helps show the problem.", nullptr);
    UiControlDesc image = UI_CONTROL_DESC_INIT;
    image.kind = UI_CONTROL_BUTTON; image.label = "ADD IMAGES";
    image.on_pressed = [](ModContext*, void*) { pick_image(); };
    svc_ui->pane_add_control(mod_ctx, left, &image, nullptr);
    if (!s_imageName.empty()) svc_ui->pane_add_text(mod_ctx, left, ("Image: " + s_imageName).c_str(), nullptr);
    UiControlDesc removeImage = UI_CONTROL_DESC_INIT;
    removeImage.kind = UI_CONTROL_BUTTON; removeImage.label = "REMOVE IMAGE";
    removeImage.on_pressed = [](ModContext*, void*) { s_imageLocation.clear(); s_imageName.clear(); };
    removeImage.is_disabled = [](ModContext*, void*) { return s_imageLocation.empty(); };
    svc_ui->pane_add_control(mod_ctx, left, &removeImage, nullptr);

    UiControlDesc video = UI_CONTROL_DESC_INIT;
    video.kind = UI_CONTROL_BUTTON; video.label = "ADD VIDEO";
    video.on_pressed = [](ModContext*, void*) { pick_video(); };
    svc_ui->pane_add_control(mod_ctx, left, &video, nullptr);
    if (!s_videoName.empty()) svc_ui->pane_add_text(mod_ctx, left, ("Video: " + s_videoName).c_str(), nullptr);
    UiControlDesc removeVideo = UI_CONTROL_DESC_INIT;
    removeVideo.kind = UI_CONTROL_BUTTON; removeVideo.label = "REMOVE VIDEO";
    removeVideo.on_pressed = [](ModContext*, void*) { s_videoLocation.clear(); s_videoName.clear(); };
    removeVideo.is_disabled = [](ModContext*, void*) { return s_videoLocation.empty(); };
    svc_ui->pane_add_control(mod_ctx, left, &removeVideo, nullptr);

    svc_ui->pane_add_text(mod_ctx, left,
        "Submitting sends your Heroes of Twilight username, report details, relevant game/mod diagnostics, and connected peer logs when available. Network addresses are scrubbed.", nullptr);

    UiControlDesc send = UI_CONTROL_DESC_INIT;
    send.kind = UI_CONTROL_BUTTON; send.label = "SEND REPORT";
    send.on_pressed = [](ModContext*, void*) { send_report(); };
    send.is_disabled = [](ModContext*, void*) { return s_sending || s_text.empty() || s_title.empty(); };
    svc_ui->pane_add_control(mod_ctx, left, &send, nullptr);

    svc_ui->pane_add_text(mod_ctx, left, s_status.c_str(), &s_statusElem);
    s_statusShown = s_status;

    svc_ui->pane_add_section(mod_ctx, right, "Choose the Problem Type");
    constexpr size_t categoryCount = sizeof(kCategories) / sizeof(kCategories[0]);
    for (size_t i = 0; i < categoryCount; ++i) {
        UiControlDesc choice = UI_CONTROL_DESC_INIT;
        choice.kind = UI_CONTROL_BUTTON;
        choice.label = kCategories[i];
        choice.user_data = reinterpret_cast<void*>(static_cast<uintptr_t>(i));
        choice.on_pressed = [](ModContext*, void* data) {
            s_category = static_cast<int>(reinterpret_cast<uintptr_t>(data));
        };
        choice.is_selected = [](ModContext*, void* data) {
            return s_category == static_cast<int>(reinterpret_cast<uintptr_t>(data));
        };
        svc_ui->pane_add_control(mod_ctx, right, &choice, nullptr);
    }

    const std::string reported = "Reported Username: " + features_local_name();
    svc_ui->pane_add_section(mod_ctx, right, "Report Details");
    svc_ui->pane_add_text(mod_ctx, right, reported.c_str(), nullptr);
    svc_ui->pane_add_text(mod_ctx, right,
        "Automatically includes relevant Heroes of Twilight session diagnostics. Passwords, tokens, private email addresses, hardware serials and personal account information are not collected by this form.", nullptr);
}

void report_update_tab() {
    if (s_statusElem == 0 || s_statusShown == s_status) return;
    s_statusShown = s_status;
    svc_ui->elem_set_text(mod_ctx, s_statusElem, s_status.c_str());
}

ConfigVarHandle s_hintVar = 0;
bool s_hintArmed = false;
uint32_t s_hintTicks = 0;

void report_hint_arm() {
    s_hintArmed = true;
}

void report_register_vars() {
    if (svc_config == nullptr) return;
    ConfigVarDesc desc = CONFIG_VAR_DESC_INIT;
    desc.name = "report_hint_shown";
    desc.type = CONFIG_VAR_BOOL;
    desc.default_bool = false;
    if (svc_config->register_var(mod_ctx, &desc, &s_hintVar) != MOD_OK) s_hintVar = 0;
}

void report_hint_update() {
    if (!s_hintArmed || s_hintVar == 0 || cfg_bool(s_hintVar, false)) return;
    if (++s_hintTicks < 120) return;
    coop_notify_c(kNotifyOther, "Found a bug?", "Report bugs in CO-OP > Report Bug");
    svc_config->set_bool(mod_ctx, s_hintVar, true);
}
