#include "linkkit.hpp"

#include "common.hpp"
#include "rarc.hpp"
#include "recolor.hpp"

#include <mods/svc/texture.h>

#include "JSystem/J3DGraphAnimator/J3DAnimation.h"
#include "JSystem/J3DGraphAnimator/J3DModelData.h"
#include "JSystem/J3DGraphBase/J3DTexture.h"
#include "JSystem/J3DGraphLoader/J3DAnmLoader.h"
#include "JSystem/JKernel/JKRArchive.h"
#include "JSystem/JKernel/JKRDecomp.h"
#include "JSystem/JKernel/JKRDvdRipper.h"
#include "JSystem/JKernel/JKRExpHeap.h"
#include "JSystem/JKernel/JKRHeap.h"
#include "d/actor/d_a_alink.h"
#include "d/d_com_inf_game.h"
#include "d/d_resorce.h"
#include "m_Do/m_Do_ext.h"

#include <algorithm>
#include <cmath>
#include <new>
#include <vector>

namespace hs::linkkit {

namespace {

// In a full room every player can keep ten independently transformed prop models. Resource data is
// shared by the game, but each J3DModel and its animation state lives in this heap. Back it with
// host memory: the game's root arena can have just under 32 MiB left, even on a machine with
// plenty of RAM. Reserving 16 MiB there and requiring another 16 MiB disabled every puppet.
constexpr u32 kHeapSize = 64u << 20;
constexpr std::align_val_t kHeapAlignment{32};
constexpr uint64_t kRetryMs = 1000;
constexpr int kAnimCacheSize = 256;

JKRExpHeap* s_heap = nullptr;
void* s_heapBuffer = nullptr;
uint64_t s_heapRetryAt = 0;
bool s_heapFailureLogged = false;
struct Raw {
    u8* data = nullptr;
    u32 size = 0;
};

Raw s_animArchive;
uint64_t s_animArchiveRetryAt = 0;

struct Files {
    uint64_t retryAt = 0;
    bool ok = false;
    Raw body, head, face, hands, sword, sheath, shield;
} s_files;

LinkModels s_shared;  // face, hands and equipment, same for every colour
bool s_sharedLoaded = false;
LinkModels s_models[kMaxPlayers];
bool s_modelsTried[kMaxPlayers] = {};

struct AnimEntry {
    u16 idx = 0xFFFF;
    J3DAnmTransform* anm = nullptr;
    u8* buffer = nullptr;
    uint64_t failedAt = 0;
};
AnimEntry s_anims[kAnimCacheSize];

struct HeapScope {
    JKRHeap* previous;
    explicit HeapScope(JKRHeap* h) : previous(mDoExt_setCurrentHeap(h)) {}
    ~HeapScope() { mDoExt_setCurrentHeap(previous); }
};

// ---- files ---------------------------------------------------------------------------------

Raw copy_out(JKRArchive* arc, const char* name) {
    Raw out;
    void* res = arc->getResource('BMWR', name);
    if (res == nullptr) {
        mods::log::warn("linkkit: {} not found", name);
        return out;
    }
    const u32 size = arc->getResSize(res);
    u8* buf = static_cast<u8*>(s_heap->alloc(size, 32));
    if (buf == nullptr) return out;
    std::memcpy(buf, res, size);
    out.data = buf;
    out.size = size;
    return out;
}

bool load_files() {
    if (s_files.ok) return true;
    if (now_ms() < s_files.retryAt) return false;
    if (heap() == nullptr) return false;
    s_files.retryAt = now_ms() + kRetryMs;

    struct Want {
        const char* arc;
        std::vector<std::pair<const char*, Raw*>> files;
    };
    const Want wants[] = {
        {"/res/Object/Kmdl.arc",
            {{"al.bmd", &s_files.body}, {"al_head.bmd", &s_files.head}, {"al_face.bmd", &s_files.face},
                {"al_hands.bmd", &s_files.hands}}},
        {"/res/Object/Alink.arc", {{"al_swa.bmd", &s_files.sword}, {"al_poda.bmd", &s_files.sheath}}},
        {"/res/Object/HyShd.arc", {{"al_sha.bmd", &s_files.shield}}},
    };
    for (const Want& want : wants) {
        if (std::all_of(want.files.begin(), want.files.end(),
                [](const auto& file) { return file.second->data != nullptr; })) continue;
        JKRArchive* arc =
            JKRArchive::mount(want.arc, JKRArchive::MOUNT_MEM, s_heap, JKRArchive::MOUNT_DIRECTION_TAIL);
        if (arc == nullptr) {
            mods::log::warn("linkkit: could not open {}", want.arc);
            continue;
        }
        for (const auto& [name, raw] : want.files) {
            if (raw->data == nullptr) *raw = copy_out(arc, name);
        }
        arc->unmount();
    }
    s_files.ok = s_files.body.data && s_files.head.data && s_files.face.data && s_files.hands.data;
    mods::log::info("linkkit: Link's files {} ({} KB free in our heap)", s_files.ok ? "ready" : "MISSING",
        s_heap->getFreeSize() / 1024);
    return s_files.ok;
}

J3DModelData* load_model(const Raw& raw, bool copy, int color) {
    if (raw.data == nullptr) return nullptr;
    u8* data = raw.data;
    if (copy) {
        data = static_cast<u8*>(s_heap->alloc(raw.size, 32));
        if (data == nullptr) return nullptr;
        std::memcpy(data, raw.data, raw.size);
        if (color > 0) recolor::bmd(data, raw.size, static_cast<uint8_t>(color));
    }
    HeapScope scope(s_heap);
    J3DModelData* model = dRes_info_c::loaderBasicBmd('BMWR', data);
    if (model != nullptr) {
        // BMWR loading enables Link's warp-disappearance texture stage. Native Link turns it
        // off during initModel(); without that step the entire puppet can fail the alpha test.
        // Rebuild the shared lists too: our permanent, non-warping models do not carry Link's
        // per-frame texgen/TEV-count diff flags to patch the original warp-enabled lists.
        dRes_info_c::offWarpMaterial(model);
        model->makeSharedDL();
    }
    return model;
}

// ---- local tunic ----------------------------------------------------------------------------

struct LocalTex {
    const void* pointer = nullptr;
    TextureReplacementHandle handle = 0;
};
std::vector<LocalTex> s_local;
int s_localColor = -1;

}  // namespace

JKRHeap* heap() {
    if (s_heap != nullptr) return s_heap;
    const uint64_t now = now_ms();
    if (now < s_heapRetryAt) return nullptr;
    s_heapRetryAt = now + kRetryMs;
    JKRHeap* root = JKRHeap::getRootHeap();
    if (root == nullptr) return nullptr;
    void* buffer = ::operator new(kHeapSize, kHeapAlignment, std::nothrow);
    if (buffer != nullptr) {
        // An explicit parent registers the external buffer in JKR's heap tree. findFromRoot()
        // searches these external child heaps too, so game allocations/disposers still work.
        s_heap = JKRExpHeap::create(buffer, kHeapSize, root, false);
        if (s_heap == nullptr) ::operator delete(buffer, kHeapAlignment);
        else s_heapBuffer = buffer;
    }
    if (s_heap == nullptr) {
        if (!s_heapFailureLogged) {
            mods::log::warn("linkkit: could not allocate {} MB for other players; will retry",
                kHeapSize >> 20);
            s_heapFailureLogged = true;
        }
        return nullptr;
    }
    s_heapFailureLogged = false;
    s_heap->setName("HideSeekHeap");
    mods::log::info("linkkit: {} MB host-memory heap for other players", kHeapSize >> 20);
    return s_heap;
}

bool ready() {
    if (!load_files()) return false;
    // Cache both poses while the local Link's archive is known to be live. Remote actors are
    // recreated during a map warp; asking for their first animation in that transition window was
    // the reason a hunter could have a name tag but no body for the whole Seek phase.
    anim(kIdleAnim);
    anim(kWalkAnim);
    return true;
}

const LinkModels* link_models(uint8_t color) {
    if (color >= kMaxPlayers || !load_files()) return nullptr;
    if (!s_sharedLoaded) {
        s_sharedLoaded = true;
        s_shared.face = load_model(s_files.face, false, 0);
        s_shared.hands = load_model(s_files.hands, false, 0);
        s_shared.sword = load_model(s_files.sword, false, 0);
        s_shared.sheath = load_model(s_files.sheath, false, 0);
        s_shared.shield = load_model(s_files.shield, false, 0);
        if (s_shared.hands != nullptr) {
            // Every hand pose is its own shape; the puppet shows one per hand.
            // Materials 0-4 are left-hand poses, 5-10 right-hand ones; show a relaxed pair.
            for (u16 i = 0; i < s_shared.hands->getMaterialNum(); ++i) {
                J3DShape* shape = s_shared.hands->getMaterialNodePointer(i)->getShape();
                if (i == 1 || i == 6) shape->show();
                else shape->hide();
            }
        }
    }
    LinkModels& m = s_models[color];
    if (!s_modelsTried[color]) {
        s_modelsTried[color] = true;
        m = s_shared;
        m.body = load_model(s_files.body, true, color);
        m.head = load_model(s_files.head, true, color);
        mods::log::info("linkkit: {} tunic {}", color_of(color).name, m.body ? "loaded" : "FAILED");
    }
    return m.body != nullptr && m.head != nullptr && m.face != nullptr && m.hands != nullptr ? &m : nullptr;
}

J3DAnmTransform* anim(uint16_t idx) {
    if (idx == 0xFFFF || heap() == nullptr) return nullptr;
    AnimEntry* slot = nullptr;
    const uint64_t now = now_ms();
    for (AnimEntry& e : s_anims) {
        if (e.idx == idx) {
            if (e.failedAt == 0) return e.anm;
            if (now - e.failedAt < kRetryMs) return nullptr;
            // A mount or allocation can fail briefly during a stage transition. A transient miss
            // must not permanently leave every remote Link on the bind-pose fallback.
            e = AnimEntry{};
            slot = &e;
            break;
        }
        if (slot == nullptr && e.idx == 0xFFFF) slot = &e;
    }
    if (slot == nullptr) return nullptr;  // cache full: the puppet falls back to idle
    slot->idx = idx;
    // Keep immutable archive bytes in our own heap. Borrowing Link's live archive races stage
    // changes, while mounting a second archive consumes the System heap needed by map loading.
    if (s_animArchive.data == nullptr && now >= s_animArchiveRetryAt) {
        s_animArchiveRetryAt = now + kRetryMs;
        constexpr u32 kMaxArchiveSize = 16u << 20;
        u32 size = 0;
        auto* data = static_cast<u8*>(JKRDvdRipper::loadToMainRAM("/res/Object/AlAnm.arc", nullptr,
            EXPAND_SWITCH_UNKNOWN1, kMaxArchiveSize, s_heap,
            JKRDvdRipper::ALLOC_DIRECTION_BACKWARD, 0, nullptr, &size));
        if (data != nullptr) {
            if (!rarc::resource_at({data, size}, kIdleAnim).empty()) s_animArchive = {data, size};
            else s_heap->free(data);
        }
    }
    if (s_animArchive.data == nullptr) {
        slot->failedAt = now;
        return nullptr;
    }
    const auto entry = rarc::resource_at({s_animArchive.data, s_animArchive.size}, idx);
    // JKR's decompressor takes a mutable pointer even though the source is never modified.
    auto* resource = entry.empty() ? nullptr : const_cast<u8*>(entry.data());
    // AlAnm's entries can be Yaz0-compressed inside the archive, and getIdxResource() on a memory
    // archive hands back those raw bytes. The animation loader rejects them, which left every
    // remote Link in the bind pose (a T-pose). Expand them the way JKRReadIdxResource() does.
    const JKRCompression compression =
        entry.size() >= 16 ? JKRCheckCompressed_noASR(resource) : COMPRESSION_NONE;
    // A resource lookup miss reports its size as (u32)-1, not 0; never trust it past a sane cap
    // (the largest of Link's BCKs is well under this) for an allocation and copy length.
    constexpr u32 kMaxAnimSize = 256 * 1024;
    u32 size = 0;
    if (resource != nullptr) {
        size = compression == COMPRESSION_NONE ? static_cast<u32>(entry.size())
                                               : JKRDecompExpandSize(resource);
    }
    u8* buffer = size != 0 && size <= kMaxAnimSize ? static_cast<u8*>(s_heap->alloc(size, 32)) : nullptr;
    if (buffer != nullptr) {
        if (compression == COMPRESSION_NONE) std::memcpy(buffer, resource, size);
        else JKRDecompress(resource, buffer, size, 0);
    }
    if (buffer == nullptr) {
        mods::log::warn("linkkit: could not copy animation #{:#x}", idx);
        slot->failedAt = now;
        return nullptr;
    }
    J3DAnmBase* loaded;
    {
        HeapScope scope(s_heap);
        loaded = J3DAnmLoaderDataBase::load(buffer);
    }
    // The concrete BCK class overrides the abstract transform kind (0) with 8. Rejecting 8
    // discarded every successfully loaded Link animation and left puppets in their bind pose.
    if (loaded == nullptr || loaded->getKind() != 8) {
        static int s_warned = 0;
        if (s_warned++ < 4) mods::log::warn("linkkit: animation #{:#x} did not load", idx);
        delete loaded;
        s_heap->free(buffer);
        slot->failedAt = now;
        return nullptr;
    }
    slot->anm = static_cast<J3DAnmTransform*>(loaded);
    slot->buffer = buffer;
    mods::log::debug("linkkit: animation #{:#x} ready ({} frames)", idx, slot->anm->getFrameMax());
    return slot->anm;
}

void recolor_local_link(uint8_t color) {
    if (svc_texture == nullptr) return;
    daAlink_c* link = daAlink_getAlinkActorClass();
    if (link == nullptr || link->checkWolf()) return;
    // Every CMPR texture of the body and the cap, each image once. A fixed list of eight filled
    // up with the body's textures first, so the cap kept its green.
    struct Wanted {
        u8* data;
        const ResTIMG* timg;
    };
    std::vector<Wanted> wanted;
    for (J3DModel* model : {link->mpLinkModel, link->mpLinkHatModel}) {
        if (model == nullptr) continue;
        J3DTexture* tex = model->getModelData()->getTexture();
        for (u16 i = 0; tex != nullptr && i < tex->getNum(); ++i) {
            const ResTIMG* timg = tex->getResTIMG(i);
            u8* data = tex->getImgDataPtr(i);
            if (timg->format != GX_TF_CMPR || data == nullptr) continue;
            const bool seen = std::any_of(wanted.begin(), wanted.end(),
                [&](const Wanted& w) { return w.data == data; });
            if (!seen) wanted.push_back({data, timg});
        }
    }
    bool same = s_localColor == color;
    if (same && color != 0) {
        same = s_local.size() == wanted.size();
        for (size_t i = 0; i < wanted.size() && same; ++i) same = s_local[i].pointer == wanted[i].data;
    }
    if (same) return;

    for (LocalTex& t : s_local) {
        if (t.handle != 0) svc_texture->unregister(mod_ctx, t.handle);
    }
    s_local.clear();
    s_localColor = color;
    if (color == 0) return;
    for (const Wanted& w : wanted) {
        const u32 width = w.timg->width, height = w.timg->height;
        const u32 mips = std::max<u32>(w.timg->mipmapCount, 1);
        const u32 bytes = recolor::cmpr_size(width, height, mips);
        std::vector<u8> copy(w.data, w.data + bytes);
        recolor::cmpr(copy.data(), bytes, color_of(color));
        TextureKey key = TEXTURE_KEY_INIT;
        key.kind = TEXTURE_KEY_POINTER;
        key.pointer = w.data;
        key.width = width;
        key.height = height;
        key.gx_format = GX_TF_CMPR;
        TextureData data = TEXTURE_DATA_INIT;
        data.data = copy.data();
        data.size = bytes;
        data.width = width;
        data.height = height;
        data.mip_count = mips;
        data.gx_format = GX_TF_CMPR;
        LocalTex t;
        t.pointer = w.data;
        svc_texture->register_data(mod_ctx, &key, &data, &t.handle);
        s_local.push_back(t);
    }
    mods::log::info("linkkit: your tunic is {} ({} textures)", color_of(color).name, s_local.size());
}

void shutdown() {
    if (svc_texture != nullptr) {
        for (LocalTex& t : s_local) {
            if (t.handle != 0) svc_texture->unregister(mod_ctx, t.handle);
        }
    }
    s_local.clear();
    s_localColor = -1;
    // Everything below lives in our heap; destroying it frees all of it at once. Puppets are
    // gone by now (the actors are deleted before the mod unloads).
    for (AnimEntry& e : s_anims) e = AnimEntry{};
    for (int i = 0; i < kMaxPlayers; ++i) {
        s_models[i] = LinkModels{};
        s_modelsTried[i] = false;
    }
    s_shared = LinkModels{};
    s_sharedLoaded = false;
    s_files = Files{};
    s_animArchive = Raw{};
    s_animArchiveRetryAt = 0;
    if (s_heap != nullptr) {
        s_heap->destroy();
        s_heap = nullptr;
    }
    // The external-buffer heap unlinks/disposes itself, but does not own its backing allocation.
    // Release it only after every game disposer and the archive volume list have been cleaned up.
    ::operator delete(s_heapBuffer, kHeapAlignment);
    s_heapBuffer = nullptr;
    s_heapRetryAt = 0;
    s_heapFailureLogged = false;
}

}  // namespace hs::linkkit
