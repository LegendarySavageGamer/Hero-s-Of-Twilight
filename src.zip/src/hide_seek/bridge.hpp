#pragma once
namespace heroes_hide_seek {
bool init();
void update();
void shutdown();
}
