// Hyrule Hide & Seek integration bridge for Heroes of Twilight.
// Donor gameplay is kept in namespace hs; this file only owns lifecycle wiring.
#include "bridge.hpp"
#include "arena.hpp"
#include "game_mode.hpp"
#include "linkkit.hpp"
#include "local.hpp"
#include "match.hpp"
#include "net.hpp"
#include "puppet.hpp"
#include "settings.hpp"
#include "treasure.hpp"
#include "ui.hpp"
#include "mods/svc/log.hpp"

namespace {
void wire_network() {
    hs::net::Events events;
    events.welcome = [] {
        hs::match::on_welcome();
        if (hs::net::is_host()) hs::match::set_settings(hs::settings::host_rules());
        hs::match::set_wanted_color(hs::settings::color());
        hs::ui::on_welcome();
    };
    events.joined = hs::match::on_joined;
    events.left = hs::match::on_left;
    events.hostChanged = hs::match::on_host_changed;
    events.message = hs::match::on_message;
    events.disconnected = [](const std::string& why) {
        hs::match::on_disconnected();
        hs::ui::on_disconnected(why);
    };
    hs::net::set_events(std::move(events));
}
}

namespace heroes_hide_seek {
bool init() {
    hs::settings::init();
    wire_network();
    hs::local::init();
    if (!hs::puppet::register_actor()) {
        mods::log::error("Heroes of Twilight: Hide & Seek could not register player actor");
        return false;
    }
    hs::ui::init();
    hs::game_mode::init();
    hs::arena::init();
    mods::log::info("Heroes of Twilight: Hyrule Hide & Seek ready (protocol {})", hs::kProtocolVersion);
    return true;
}
void update() {
    hs::net::update();
    hs::match::update();
    hs::local::update();
    hs::treasure::update();
    hs::puppet::update();
    hs::game_mode::update();
    hs::arena::update();
}
void shutdown() {
    hs::net::leave_room();
    hs::local::shutdown();
    hs::arena::shutdown();
    hs::ui::shutdown();
    if (hs::puppet::unregister_actor()) hs::linkkit::shutdown();
    else mods::log::warn("Heroes of Twilight: Hide & Seek puppets still alive at shutdown");
}
}
