#pragma once

#include "mods/svc/config.h"
#include "mods/svc/websocket.hpp"
#include <cstddef>
#include <cstdint>
#include <string>
#include <span>
#include <vector>

struct PlayerSnapshot;
struct GlobalPlayer;

struct GlobalVoicePeerState {
    std::string name;
    char stage[9] = {};
    int8_t room = -1;
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
    bool valid = false;
};

void global_client_init();
void global_client_update();
void global_client_shutdown();
void global_client_connect();
void global_client_disconnect();
bool global_client_connected();
bool global_client_connecting();
bool global_client_owns_websocket(WebSocketHandle handle);
void global_client_on_websocket_event(const mods::ws::Event& event);
uint32_t global_client_player_count();
uint32_t global_client_here_count();
uint64_t global_client_player_id();
std::string global_client_status();
std::string global_client_endpoint();
std::string global_client_debug_status();
ConfigVarHandle global_client_username_var();
bool global_client_send_chat(const std::string& text);
bool global_client_send_voice(uint32_t sequence, bool speaking, std::span<const uint8_t> opus);
std::string global_client_local_name();
std::string global_client_player_name(uint64_t globalId);
bool global_client_voice_peer_state(uint64_t globalId, GlobalVoicePeerState& out);
void global_client_set_blocked(const GlobalPlayer& who, bool on);
std::vector<GlobalPlayer> global_client_players();

// Visual-only Global Twilight bridge into the existing Crests player system.
void global_client_send_snapshot(const PlayerSnapshot& snapshot);
void global_client_send_colors(const void* payload, size_t size);
void global_client_send_sounds(const void* payload, size_t size);
bool global_client_slot_present(uint8_t slot);
uint64_t global_client_id_for_slot(uint8_t slot);
bool global_client_peer_pvp_enabled(uint8_t slot);
bool global_client_send_pvp_state(bool enabled);
bool global_client_send_pvp_hit(uint8_t targetSlot, const void* payload, size_t size);
uint16_t global_client_roster_mask();
