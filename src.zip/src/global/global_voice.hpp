#pragma once

#include "mods/svc/config.h"

#include <cstdint>
#include <span>
#include <string>
#include <vector>

// Complete Hyrule Online voice bridge for v1.9.3. Audio capture/codec/playback
// is adapted from MFB/Dusklight Online; transport remains Heroes of Twilight's
// existing Global relay so private co-op and Global progression rules stay isolated.
void global_voice_init();
void global_voice_update();
void global_voice_shutdown();
void global_voice_peer_left(uint64_t globalId);
void global_voice_receive(uint64_t globalId, uint8_t slot, uint32_t sequence,
                          bool speaking, std::span<const uint8_t> opus);

ConfigVarHandle global_voice_enabled_var();
ConfigVarHandle global_voice_proximity_var();
ConfigVarHandle global_voice_range_var();
ConfigVarHandle global_voice_input_var();
ConfigVarHandle global_voice_mic_volume_var();
ConfigVarHandle global_voice_player_volume_var();
ConfigVarHandle global_voice_muted_var();
ConfigVarHandle global_voice_mute_hotkey_var();

std::vector<std::string> global_voice_input_devices();
std::string global_voice_status();
std::string global_voice_hotkey_name();
void global_voice_begin_hotkey_capture();
bool global_voice_hotkey_capture_active();
std::vector<std::string> global_voice_overlay_lines();
