#include "global_client.hpp"
#include "global_voice.hpp"

#include "../print.hpp"
#include "../mod.hpp"
#include "../net/messages.hpp"
#include "../net/protocol.hpp"
#include "../net/json.hpp"

#include "d/actor/d_a_alink.h"
#include "d/d_com_inf_game.h"
#include "f_op/f_op_actor_mng.h"

#include "mods/svc/websocket.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <span>
#include <string>
#include <vector>

extern const WebSocketService* svc_websocket;
extern const ConfigService* svc_config;

#ifndef GLOBAL_TWILIGHT_ENDPOINT
#define GLOBAL_TWILIGHT_ENDPOINT "wss://crests-rooms.twilight-heroes.workers.dev/global"
#endif

namespace {
mods::ws::Connection s_ws;
bool s_connecting = false;
bool s_connected = false;
uint32_t s_players = 0;
uint32_t s_here = 0;
std::string s_area;
uint32_t s_areaTick = 0;
uint64_t s_id = 0;
std::string s_status = "Not connected.";
uint32_t s_tick = 0;
uint32_t s_presenceTick = 0;
ConfigVarHandle s_usernameVar = 0;
uint32_t s_lastSkinStamp = 0;

uint32_t s_txPresence = 0;
uint32_t s_txSnapshots = 0;
uint32_t s_txSkins = 0;
uint32_t s_rxPresence = 0;
uint32_t s_rxSnapshots = 0;
uint32_t s_rxSkins = 0;
uint32_t s_rxColors = 0;
uint32_t s_rxSounds = 0;
uint32_t s_rxVoice = 0;
uint32_t s_txVoice = 0;
uint32_t s_rxBad = 0;

constexpr uint32_t kGlobalMagic = 0x314C4247u; // GBL1 on little-endian clients.
constexpr uint8_t kGlobalPresence = 1;
constexpr uint8_t kGlobalSnapshot = 2;
constexpr uint8_t kGlobalSkinChoices = 3;
constexpr uint8_t kGlobalColors = 4;
constexpr uint8_t kGlobalSounds = 5;
constexpr uint8_t kGlobalVoice = 6;
constexpr uint8_t kGlobalPvpState = 7;
constexpr uint8_t kGlobalPvpHit = 8;
constexpr uint32_t kGlobalSlotStaleTicks = 60 * 10;
constexpr int32_t kGlobalSeqRestartGap = 240;

#pragma pack(push, 1)
struct GlobalFrameHeader {
    uint32_t magic;
    uint8_t type;
    uint8_t reserved[3];
    uint64_t sender;
    uint32_t payloadSize;
};
#pragma pack(pop)

struct GlobalSlot {
    uint64_t globalId = 0;
    bool pvpEnabled = false;
    std::string tag;
    std::string name;
    uint32_t lastSeen = 0;
    uint32_t lastSnapshotSeq = 0;
    bool haveSnapshotSeq = false;
    char voiceStage[9] = {};
    int8_t voiceRoom = -1;
    float voiceX = 0.0f;
    float voiceY = 0.0f;
    float voiceZ = 0.0f;
    bool voicePositionValid = false;
    bool used = false;
};

std::array<GlobalSlot, kCoopMaxPlayers> s_slots{};
uint16_t s_globalRoster = 0;

std::string global_username() {
    std::string name = cfg_string(s_usernameVar, "");
    if (name.empty()) name = features_local_name();
    if (name.empty()) name = "Player";
    if (name.size() >= static_cast<size_t>(kCoopNameMax)) name.resize(kCoopNameMax - 1);
    return name;
}

void copy_wire_name(char* dest, size_t cap, const std::string& name) {
    if (dest == nullptr || cap == 0) return;
    std::memset(dest, 0, cap);
    const size_t n = name.size() < cap - 1 ? name.size() : cap - 1;
    if (n != 0) std::memcpy(dest, name.data(), n);
}

std::string json_escape(const std::string& in) {
    std::string out;
    out.reserve(in.size() + 8);
    for (char c : in) {
        if (c == '\\' || c == '"') { out.push_back('\\'); out.push_back(c); }
        else if (c == '\n') out += "\\n";
        else if (static_cast<unsigned char>(c) >= 0x20) out.push_back(c);
    }
    return out;
}

std::string current_area() {
    const char* stage = dComIfGp_getStartStageName();
    if (stage == nullptr) return "";
    std::string out(stage);
    if (out.size() > 8) out.resize(8);
    return out;
}

void send_hello() {
    if (!s_ws || !s_connected || s_id == 0) return;
    const std::string key = global_install_key_bridge();
    const std::string msg = "{\"op\":\"hello\",\"name\":\"" + json_escape(global_username()) +
        "\",\"key\":\"" + json_escape(key) + "\",\"v\":73}";
    (void)s_ws.send_text(msg);
    s_area.clear();
    s_areaTick = 999;
}

void send_area_if_needed(bool force = false) {
    if (!s_ws || !s_connected || s_id == 0) return;
    const std::string area = current_area();
    if (!force && area == s_area) return;
    s_area = area;
    (void)s_ws.send_text("{\"op\":\"area\",\"stage\":\"" + json_escape(area) + "\"}");
}

void reset_counters() {
    s_txPresence = s_txSnapshots = s_txSkins = 0;
    s_rxPresence = s_rxSnapshots = s_rxSkins = s_rxColors = s_rxSounds = s_rxVoice = s_rxBad = 0;
    s_txVoice = 0;
}

void release_slot(uint8_t slot) {
    if (slot == 0 || slot >= kCoopMaxPlayers || !s_slots[slot].used) return;
    const uint64_t old = s_slots[slot].globalId;
    global_voice_peer_left(old);
    s_slots[slot] = GlobalSlot{};
    s_globalRoster = static_cast<uint16_t>(s_globalRoster & ~(1u << slot));
    features_global_forget_peer(slot);
    puppet_hook_release_player(slot);
    coop_log::info("coop_mod: [GLOBAL] released Global {} from puppet slot {}", old, slot);
}

void release_all_slots() {
    for (uint8_t slot = 1; slot < kCoopMaxPlayers; ++slot) release_slot(slot);
    s_globalRoster = 0;
}

int slot_for(uint64_t globalId, bool create) {
    if (globalId == 0 || globalId == s_id) return -1;
    for (int slot = 1; slot < kCoopMaxPlayers; ++slot) {
        if (s_slots[slot].used && s_slots[slot].globalId == globalId) {
            s_slots[slot].lastSeen = s_tick;
            return slot;
        }
    }
    if (!create) return -1;
    for (int slot = 1; slot < kCoopMaxPlayers; ++slot) {
        if (!s_slots[slot].used) {
            s_slots[slot].used = true;
            s_slots[slot].globalId = globalId;
            s_slots[slot].lastSeen = s_tick;
            s_globalRoster = static_cast<uint16_t>(s_globalRoster | (1u << slot));
            coop_log::info("coop_mod: [GLOBAL] Global {} -> local Crests puppet slot {}", globalId, slot);
            return slot;
        }
    }
    coop_log::warn("coop_mod: [GLOBAL] no free local puppet slot for Global {}", globalId);
    return -1;
}

bool fresh_global_snapshot(GlobalSlot& slot, uint32_t seq) {
    if (slot.haveSnapshotSeq) {
        const int32_t ahead = static_cast<int32_t>(seq - slot.lastSnapshotSeq);
        if (ahead <= 0 && ahead > -kGlobalSeqRestartGap) return false;
    }
    slot.haveSnapshotSeq = true;
    slot.lastSnapshotSeq = seq;
    return true;
}

bool send_binary(uint8_t type, const void* payload, size_t size) {
    if (!s_ws || !s_connected || s_id == 0 || payload == nullptr || size == 0) return false;
    GlobalFrameHeader head{};
    head.magic = kGlobalMagic;
    head.type = type;
    head.sender = s_id;
    head.payloadSize = static_cast<uint32_t>(size);
    std::vector<std::byte> frame(sizeof(head) + size);
    std::memcpy(frame.data(), &head, sizeof(head));
    std::memcpy(frame.data() + sizeof(head), payload, size);
    return s_ws.send_binary(std::span<const std::byte>(frame.data(), frame.size())) == MOD_OK;
}

void send_skin_choices() {
    MsgSkinChoices msg{};
    features_build_global_skin_choices(&msg);
    if (send_binary(kGlobalSkinChoices, &msg, sizeof(msg))) ++s_txSkins;
}

void send_presence() {
    MsgPresence msg{};
    features_build_global_presence(&msg);
    copy_wire_name(msg.name, sizeof(msg.name), global_username());
    if (send_binary(kGlobalPresence, &msg, sizeof(msg))) ++s_txPresence;
    if (msg.skinStamp != s_lastSkinStamp) {
        s_lastSkinStamp = msg.skinStamp;
        send_skin_choices();
    }
}

bool same_place(uint8_t slot) {
    const CoopPeer& peer = features_peer_of(slot);
    if (!peer.present || !peer.inGame || peer.stage[0] == '\0') return false;
    const char* ours = dComIfGp_getStartStageName();
    if (ours == nullptr || std::strncmp(ours, peer.stage, 8) != 0) return false;
    daAlink_c* me = daAlink_getAlinkActorClass();
    if (me == nullptr) return false;
    const int room = fopAcM_GetRoomNo(me);
    return peer.curRoom < 0 || peer.curRoom == room;
}

void parse_binary(const std::byte* data, size_t size) {
    if (data == nullptr || size < sizeof(GlobalFrameHeader)) { ++s_rxBad; return; }
    GlobalFrameHeader head{};
    std::memcpy(&head, data, sizeof(head));
    if (head.magic != kGlobalMagic || head.sender == 0 || head.sender == s_id ||
        head.payloadSize != size - sizeof(head)) {
        ++s_rxBad;
        return;
    }

    const uint8_t* payload = reinterpret_cast<const uint8_t*>(data + sizeof(head));

    // Identity/presence is what creates the mapping. Snapshots never create an
    // anonymous puppet slot by themselves; they wait for that player's presence.
    if (head.type == kGlobalPresence && head.payloadSize == sizeof(MsgPresence)) {
        // A player who was already online may have broadcast their skin choices before
        // we joined. Private Crests has a SkinRequest handshake; Global instead resends
        // our current cosmetic state once whenever a new remote player first appears.
        const bool newlySeen = slot_for(head.sender, false) < 1;
        const int assigned = slot_for(head.sender, true);
        if (assigned < 1 || assigned >= kCoopMaxPlayers) return;
        const uint8_t slot = static_cast<uint8_t>(assigned);
        MsgPresence msg{};
        std::memcpy(&msg, payload, sizeof(msg));
        msg.storyBits = 0; // Explicit Global allowlist: never import story state.
        std::memcpy(s_slots[slot].voiceStage, msg.stage, sizeof(msg.stage));
        s_slots[slot].voiceStage[8] = '\0';
        s_slots[slot].voiceRoom = msg.curRoom;
        s_slots[slot].voiceX = msg.x;
        s_slots[slot].voiceY = msg.y;
        s_slots[slot].voiceZ = msg.z;
        s_slots[slot].voicePositionValid = msg.inGame != 0;
        features_global_receive_presence(slot, &msg);
        s_slots[slot].lastSeen = s_tick;
        ++s_rxPresence;
        if (newlySeen) {
            // Make sure the newcomer immediately learns what we were already wearing.
            send_skin_choices();
            colors_resend();
        }
        if (!same_place(slot)) puppet_hook_release_player(slot);
        return;
    }

    if (head.type == kGlobalVoice) {
        // v1.9.3 voice packet: [u32 sequence][u8 speaking][Opus payload].
        // Require an existing Global identity/puppet slot so audio cannot bypass
        // player identity, block state, or proximity state.
        if (head.payloadSize <= sizeof(uint32_t) + 1 ||
            head.payloadSize > sizeof(uint32_t) + 1 + 400) {
            ++s_rxBad;
            return;
        }
        const int assigned = slot_for(head.sender, false);
        if (assigned < 1 || assigned >= kCoopMaxPlayers) return;
        const uint8_t slot = static_cast<uint8_t>(assigned);
        if (!s_slots[slot].tag.empty() && global_blocked(s_slots[slot].tag)) return;
        uint32_t sequence = 0;
        std::memcpy(&sequence, payload, sizeof(sequence));
        const bool speaking = payload[sizeof(sequence)] != 0;
        global_voice_receive(head.sender, slot, sequence, speaking,
            std::span<const uint8_t>(payload + sizeof(sequence) + 1,
                                     head.payloadSize - sizeof(sequence) - 1));
        ++s_rxVoice;
        return;
    }

    if (head.type == kGlobalPvpState && head.payloadSize == 1) {
        const int pvpSlot = slot_for(head.sender, false);
        if (pvpSlot > 0 && pvpSlot < kCoopMaxPlayers) {
            s_slots[pvpSlot].pvpEnabled = payload[0] != 0;
        }
        return;
    }
    if (head.type == kGlobalPvpHit) {
        struct WireHead { uint64_t target; };
        if (head.payloadSize < sizeof(WireHead)) return;
        WireHead wh{}; std::memcpy(&wh, payload, sizeof(wh));
        if (wh.target != s_id) return;
        pvp_on_global_hit(payload + sizeof(wh), head.payloadSize - sizeof(wh), head.sender);
        return;
    }

    const int assigned = slot_for(head.sender, false);
    if (assigned < 1 || assigned >= kCoopMaxPlayers) return;
    const uint8_t slot = static_cast<uint8_t>(assigned);
    s_slots[slot].lastSeen = s_tick;

    if (head.type == kGlobalSkinChoices && head.payloadSize == sizeof(MsgSkinChoices)) {
        MsgSkinChoices msg{};
        std::memcpy(&msg, payload, sizeof(msg));
        features_global_receive_skin_choices(slot, &msg);
        ++s_rxSkins;
        return;
    }

    if (head.type == kGlobalColors && head.payloadSize == sizeof(MsgColorEntry) * kCoopColorSlots) {
        colors_on_message(payload, head.payloadSize, slot);
        ++s_rxColors;
        return;
    }

    if (head.type == kGlobalSounds) {
        // Reuse Private Crests' existing sound path. fx_on_sounds() asks the existing
        // puppet system for the sender position and naturally ignores players that do
        // not have a relevant remote puppet/position on this client.
        fx_on_sounds(payload, head.payloadSize, slot);
        ++s_rxSounds;
        return;
    }

    if (head.type == kGlobalSnapshot && head.payloadSize == sizeof(PlayerSnapshot)) {
        PlayerSnapshot snapshot{};
        std::memcpy(&snapshot, payload, sizeof(snapshot));
        if (!fresh_global_snapshot(s_slots[slot], snapshot.seq)) return;
        ++s_rxSnapshots;
        s_slots[slot].voiceRoom = snapshot.roomNo;
        s_slots[slot].voiceX = snapshot.posX;
        s_slots[slot].voiceY = snapshot.posY;
        s_slots[slot].voiceZ = snapshot.posZ;
        s_slots[slot].voicePositionValid = true;
        if (!same_place(slot)) {
            puppet_hook_release_player(slot);
            return;
        }
        snapshot.playerId = slot;
        // This enters the shared Private/Global visual application path in mod.cpp.
        coop_accept_global_snapshot(slot, snapshot);
        return;
    }

    ++s_rxBad;
}

void parse_text(const std::string& raw) {
    std::string line = raw;
    while (!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
    if (!line.empty() && line.front() == '{') {
        JsonObject msg;
        JsonReader reader(line);
        if (!reader.object(msg)) return;
        const std::string op = msg.str("op");
        if (op == "count") {
            try { s_players = static_cast<uint32_t>(std::stoul(msg.str("total"))); } catch (...) {}
            try { s_here = static_cast<uint32_t>(std::stoul(msg.str("here"))); } catch (...) {}
            return;
        }
        if (op == "chat") {
            uint32_t id = 0; try { id = static_cast<uint32_t>(std::stoul(msg.str("id"))); } catch (...) {}
            const std::string tag = msg.str("tag");
            if (!global_blocked(tag)) chat_on_message(id, tag, msg.str("name"), msg.str("text"));
            return;
        }
        if (op == "peer") {
            uint64_t id = 0; try { id = std::stoull(msg.str("id")); } catch (...) {}
            const int slot = slot_for(id, true);
            if (slot > 0) { s_slots[slot].tag = msg.str("tag"); s_slots[slot].name = msg.str("name"); }
            return;
        }
        if (op == "gone") {
            uint64_t id = 0; try { id = std::stoull(msg.str("id")); } catch (...) {}
            const int slot = slot_for(id, false); if (slot > 0) release_slot(static_cast<uint8_t>(slot));
            return;
        }
        if (op == "chat_slow") { chat_note("Slow down a little."); return; }
        if (op == "chat_banned") { chat_note("You can't use chat."); return; }
        return;
    }
    if (line.rfind("ID ", 0) == 0) {
        try { s_id = std::stoull(line.substr(3)); } catch (...) { s_id = 0; }
        s_status = "Connected to Hyrule Online.";
        send_hello();
        send_area_if_needed(true);
        send_presence();
        return;
    }
    if (line.rfind("COUNT ", 0) == 0) {
        try { s_players = static_cast<uint32_t>(std::stoul(line.substr(6))); } catch (...) {}
        return;
    }
    if (line.rfind("READY", 0) == 0) {
        s_status = "Connected to Hyrule Online. Player relay ready.";
        // The Heroes Global client owns the active Hyrule Online connection.
        // Remi's original Global path calls this after its hello succeeds; do
        // the same here so the real chat instructions appear once, only after
        // the Heroes relay has accepted our hello.
        chat_first_online();
        return;
    }
    if (line.rfind("ERROR ", 0) == 0) s_status = line.substr(6);
}
} // namespace

void global_client_init() {
    release_all_slots();
    s_tick = 0;
    s_presenceTick = 0;
    s_lastSkinStamp = 0;
    reset_counters();
    if (svc_config != nullptr && s_usernameVar == 0) {
        ConfigVarDesc d = CONFIG_VAR_DESC_INIT;
        d.name = "global_username";
        d.type = CONFIG_VAR_STRING;
        d.default_string = "";
        svc_config->register_var(mod_ctx, &d, &s_usernameVar);
    }
    s_status = "Not connected. Choose a Global username, then press Join Global.";
}

void global_client_update() {
    ++s_tick;
    if (!s_connected) return;
    if (++s_presenceTick >= 30) {
        s_presenceTick = 0;
        send_presence();
    }
    if (++s_areaTick >= 30) {
        s_areaTick = 0;
        send_area_if_needed();
    }
    for (uint8_t slot = 1; slot < kCoopMaxPlayers; ++slot) {
        if (!s_slots[slot].used) continue;
        if (s_tick - s_slots[slot].lastSeen > kGlobalSlotStaleTicks) release_slot(slot);
    }
}

void global_client_connect() {
    if (s_connected || s_connecting) return;
    if (coop_net_connected() || coop_net_connecting()) {
        s_status = "Disconnect Private Co-op before joining Global.";
        return;
    }
    if (svc_websocket == nullptr) {
        s_status = "WebSocket service is unavailable on this Dusklight build.";
        return;
    }
    release_all_slots();
    s_ws = mods::ws::Connection{};
    s_players = 0;
    s_here = 0;
    s_area.clear();
    s_id = 0;
    s_presenceTick = 0;
    s_lastSkinStamp = 0;
    reset_counters();

    mods::ws::Options options;
    options.url = GLOBAL_TWILIGHT_ENDPOINT;
    options.connectTimeoutMs = 10000;
    options.keepaliveIntervalMs = 15000;
    options.maxMessageBytes = 64 * 1024;
    s_ws = mods::ws::connect(options);
    if (!s_ws) {
        s_status = "Could not start the Global connection.";
        return;
    }
    s_connecting = true;
    s_status = "Connecting to Hyrule Online...";
    coop_log::info("coop_mod: [GLOBAL] connecting to {} as '{}'", GLOBAL_TWILIGHT_ENDPOINT,
        global_username());
}

void global_client_disconnect() {
    if (s_ws) {
        (void)s_ws.send_text("BYE");
        (void)s_ws.close(1000, "leaving Hyrule Online");
    }
    s_ws = mods::ws::Connection{};
    s_connecting = false;
    s_connected = false;
    s_players = 0;
    s_here = 0;
    s_area.clear();
    s_id = 0;
    s_lastSkinStamp = 0;
    release_all_slots();
    s_status = "Not connected. Choose a Global username, then press Join Global.";
}

void global_client_shutdown() { global_client_disconnect(); }

bool global_client_connected() { return s_connected; }
bool global_client_connecting() { return s_connecting; }
uint32_t global_client_player_count() { return s_players; }
uint32_t global_client_here_count() {
    // Count the same remote Global heroes that Heroes already considers
    // relevant enough to render here.  This deliberately excludes the local
    // player and does not derive the value from the total-online count.
    uint32_t here = 0;
    for (uint8_t slot = 1; slot < kCoopMaxPlayers; ++slot) {
        if (!s_slots[slot].used) continue;
        if (same_place(slot)) ++here;
    }
    return here;
}
uint64_t global_client_player_id() { return s_id; }
std::string global_client_status() { return s_status; }
std::string global_client_endpoint() { return GLOBAL_TWILIGHT_ENDPOINT; }

uint64_t global_client_id_for_slot(uint8_t slot) {
    return slot < kCoopMaxPlayers && s_slots[slot].used ? s_slots[slot].globalId : 0;
}

bool global_client_peer_pvp_enabled(uint8_t slot) {
    return slot < kCoopMaxPlayers && s_slots[slot].used && s_slots[slot].pvpEnabled;
}

bool global_client_send_pvp_state(bool enabled) {
    const uint8_t value = enabled ? 1 : 0;
    return send_binary(kGlobalPvpState, &value, sizeof(value));
}

bool global_client_send_pvp_hit(uint8_t targetSlot, const void* payload, size_t size) {
    const uint64_t target = global_client_id_for_slot(targetSlot);
    if (target == 0 || payload == nullptr || size == 0) return false;
    std::vector<uint8_t> wire(sizeof(target) + size);
    std::memcpy(wire.data(), &target, sizeof(target));
    std::memcpy(wire.data() + sizeof(target), payload, size);
    return send_binary(kGlobalPvpHit, wire.data(), wire.size());
}

uint16_t global_client_roster_mask() { return s_globalRoster; }
ConfigVarHandle global_client_username_var() { return s_usernameVar; }

std::string global_client_debug_status() {
    int mapped = 0;
    for (uint8_t slot = 1; slot < kCoopMaxPlayers; ++slot) if (s_slots[slot].used) ++mapped;
    return "Global visual relay: mapped " + std::to_string(mapped) +
           " | presence RX " + std::to_string(s_rxPresence) +
           " | snapshots RX " + std::to_string(s_rxSnapshots) +
           " | skin RX " + std::to_string(s_rxSkins) +
           " | colors RX " + std::to_string(s_rxColors) +
           " | sounds RX " + std::to_string(s_rxSounds) +
           " | voice TX/RX " + std::to_string(s_txVoice) + "/" + std::to_string(s_rxVoice) +
           " | bad " + std::to_string(s_rxBad);
}

bool global_client_slot_present(uint8_t slot) {
    return slot < kCoopMaxPlayers && s_slots[slot].used;
}

void global_client_send_snapshot(const PlayerSnapshot& snapshot) {
    if (send_binary(kGlobalSnapshot, &snapshot, sizeof(snapshot))) ++s_txSnapshots;
}

void global_client_send_colors(const void* payload, size_t size) {
    (void)send_binary(kGlobalColors, payload, size);
}

void global_client_send_sounds(const void* payload, size_t size) {
    (void)send_binary(kGlobalSounds, payload, size);
}

bool global_client_send_chat(const std::string& text) {
    if (!s_ws || !s_connected || s_id == 0) return false;
    return s_ws.send_text("{\"op\":\"chat\",\"text\":\"" + json_escape(text) + "\"}") == MOD_OK;
}

bool global_client_send_voice(uint32_t sequence, bool speaking, std::span<const uint8_t> opus) {
    if (!s_connected || s_id == 0 || sequence == 0 || opus.empty() || opus.size() > 400) return false;
    std::vector<uint8_t> payload(sizeof(sequence) + 1 + opus.size());
    std::memcpy(payload.data(), &sequence, sizeof(sequence));
    payload[sizeof(sequence)] = speaking ? 1 : 0;
    std::memcpy(payload.data() + sizeof(sequence) + 1, opus.data(), opus.size());
    if (!send_binary(kGlobalVoice, payload.data(), payload.size())) return false;
    ++s_txVoice;
    return true;
}

void global_client_set_blocked(const GlobalPlayer& who, bool on) {
    if (!s_ws || !s_connected || who.id == 0) return;
    (void)s_ws.send_text(std::string("{\"op\":\"") + (on ? "block" : "unblock") +
        "\",\"id\":" + std::to_string(who.id) + "}");
    if (on) {
        const int slot = slot_for(who.id, false);
        if (slot > 0) release_slot(static_cast<uint8_t>(slot));
    }
}


std::string global_client_local_name() { return global_username(); }

std::string global_client_player_name(uint64_t globalId) {
    if (globalId == s_id) return global_username();
    const int slot = slot_for(globalId, false);
    if (slot < 1 || slot >= kCoopMaxPlayers) return {};
    if (!s_slots[slot].name.empty()) return s_slots[slot].name;
    return features_peer_of(static_cast<uint8_t>(slot)).name;
}

bool global_client_voice_peer_state(uint64_t globalId, GlobalVoicePeerState& out) {
    out = GlobalVoicePeerState{};
    const int slot = slot_for(globalId, false);
    if (slot < 1 || slot >= kCoopMaxPlayers) return false;
    const GlobalSlot& src = s_slots[slot];
    out.name = !src.name.empty() ? src.name : features_peer_of(static_cast<uint8_t>(slot)).name;
    std::memcpy(out.stage, src.voiceStage, sizeof(out.stage));
    out.stage[8] = '\0';
    out.room = src.voiceRoom;
    out.x = src.voiceX; out.y = src.voiceY; out.z = src.voiceZ;
    out.valid = src.voicePositionValid && src.voiceStage[0] != '\0';
    return true;
}

std::vector<GlobalPlayer> global_client_players() {
    std::vector<GlobalPlayer> out;
    for (uint8_t slot = 1; slot < kCoopMaxPlayers; ++slot) {
        if (!s_slots[slot].used || s_slots[slot].globalId == 0) continue;
        const CoopPeer& peer = features_peer_of(slot);
        std::string name = s_slots[slot].name;
        if (name.empty() && peer.present) name = peer.name;
        if (name.empty()) name = "Hero";
        out.push_back(GlobalPlayer{static_cast<uint32_t>(s_slots[slot].globalId), name, s_slots[slot].tag});
    }
    return out;
}

bool global_client_owns_websocket(WebSocketHandle handle) {
    return s_ws && handle == s_ws.handle();
}

void global_client_on_websocket_event(const mods::ws::Event& event) {
    if (!global_client_owns_websocket(event.handle)) return;
    switch (event.type) {
    case WEBSOCKET_EVENT_OPEN:
        s_connecting = false;
        s_connected = true;
        s_status = "Connected. Registering with Hyrule Online...";
        break;
    case WEBSOCKET_EVENT_MESSAGE:
        if (event.messageKind == WEBSOCKET_MESSAGE_TEXT) {
            parse_text(std::string(reinterpret_cast<const char*>(event.data.data()), event.data.size()));
        } else if (event.messageKind == WEBSOCKET_MESSAGE_BINARY) {
            parse_binary(event.data.data(), event.data.size());
        }
        break;
    case WEBSOCKET_EVENT_CLOSED:
        s_ws.detach();
        s_ws = mods::ws::Connection{};
        s_connecting = false;
        s_connected = false;
        s_players = 0;
        s_id = 0;
        release_all_slots();
        s_status = "Global connection closed.";
        break;
    default:
        break;
    }
}
