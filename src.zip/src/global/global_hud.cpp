#include "global_hud.hpp"
#include "global_client.hpp"
#include "global_voice.hpp"

#include "../print.hpp"
#include "../util.hpp"

#include "mods/svc/hook.hpp"
#include "JSystem/J2DGraph/J2DOrthoGraph.h"
#include "JSystem/JUtility/JUTFont.h"
#include "JSystem/JUtility/TColor.h"
#include "d/d_com_inf_game.h"
#include "m_Do/m_Do_ext.h"
#include "m_Do/m_Do_graphic.h"

#include <algorithm>
#include <string>
#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#endif

extern const ConfigService* svc_config;

DEFINE_HOOK(&dComIfGd_draw2DXlu, GlobalHudDraw2DXluHook);

namespace {
ConfigVarHandle s_enabled = 0;
ConfigVarHandle s_x = 0;
ConfigVarHandle s_y = 0;
ConfigVarHandle s_size = 0;
ConfigVarHandle s_opacity = 0;
bool s_hooked = false;
bool s_dragging = false;
f32 s_dragOffsetX = 0.0f;
f32 s_dragOffsetY = 0.0f;

ConfigVarHandle reg_bool(const char* name, bool fallback) {
    ConfigVarDesc d = CONFIG_VAR_DESC_INIT;
    d.name = name;
    d.type = CONFIG_VAR_BOOL;
    d.default_bool = fallback;
    ConfigVarHandle h = 0;
    svc_config->register_var(mod_ctx, &d, &h);
    return h;
}
ConfigVarHandle reg_int(const char* name, int64_t fallback) {
    ConfigVarDesc d = CONFIG_VAR_DESC_INIT;
    d.name = name;
    d.type = CONFIG_VAR_INT;
    d.default_int = fallback;
    ConfigVarHandle h = 0;
    svc_config->register_var(mod_ctx, &d, &h);
    return h;
}
bool cfg_bool(ConfigVarHandle h, bool fallback) {
    bool v = fallback;
    if (h != 0) svc_config->get_bool(mod_ctx, h, &v);
    return v;
}
int64_t cfg_int(ConfigVarHandle h, int64_t fallback) {
    int64_t v = fallback;
    if (h != 0) svc_config->get_int(mod_ctx, h, &v);
    return v;
}

void draw_hud() {
    if (!s_hooked || !global_client_connected() || !cfg_bool(s_enabled, true)) return;
    JUTFont* font = mDoExt_getMesgFont();
    if (font == nullptr) return;

    const f32 minX = mDoGph_gInf_c::getMinXF();
    const f32 minY = mDoGph_gInf_c::getMinYF();
    const f32 width = mDoGph_gInf_c::getWidthF();
    const f32 height = mDoGph_gInf_c::getHeightF();
    J2DOrthoGraph ortho(0.0f, 0.0f, static_cast<f32>(FB_WIDTH), static_cast<f32>(FB_HEIGHT), -1.0f, 1.0f);
    ortho.setOrtho(minX, minY, width, height, -1.0f, 1.0f);
    ortho.setPort();

    const int xPct = std::clamp<int>(static_cast<int>(cfg_int(s_x, 50)), 0, 100);
    const int yPct = std::clamp<int>(static_cast<int>(cfg_int(s_y, 14)), 0, 100);
    const f32 scale = std::clamp<f32>(static_cast<f32>(cfg_int(s_size, 100)) / 100.0f, 0.5f, 2.0f);
    const u8 alpha = static_cast<u8>(std::clamp<int>(static_cast<int>(cfg_int(s_opacity, 82)), 20, 100) * 255 / 100);
    const f32 cell = 16.0f * scale;
    const f32 padX = 13.0f * scale;
    const f32 padY = 8.0f * scale;
    const std::string line1 = "Hero's Saving Hyrule - " + std::to_string(global_client_player_count());
    const std::string line2 = "Heroes In This Area - " + std::to_string(global_client_here_count());
    const f32 textW = std::max(coop_text_width(font, line1.c_str(), cell), coop_text_width(font, line2.c_str(), cell));
    const f32 boxW = textW + padX * 2.0f;
    const f32 boxH = cell * 2.0f + padY * 2.0f;
    f32 cx = minX + width * (static_cast<f32>(xPct) / 100.0f);
    f32 cy = minY + height * (static_cast<f32>(yPct) / 100.0f);
    f32 x0 = std::clamp(cx - boxW * 0.5f, minX + 4.0f, minX + width - boxW - 4.0f);
    f32 y0 = std::clamp(cy - boxH * 0.5f, minY + 4.0f, minY + height - boxH - 4.0f);

    // Mouse interaction for the Hyrule Online counter on Windows.
    // Use Win32 directly instead of depending on Dear ImGui headers; the
    // Dusklight SDK package used by this project does not ship imgui.h itself.
#if defined(_WIN32)
    static bool prevLeftDown = false;
    static bool prevRightDown = false;
    POINT mouse{};
    HWND hwnd = GetForegroundWindow();
    RECT client{};
    if (hwnd != nullptr && GetCursorPos(&mouse) && ScreenToClient(hwnd, &mouse) && GetClientRect(hwnd, &client)) {
        const LONG clientW = client.right - client.left;
        const LONG clientH = client.bottom - client.top;
        if (clientW > 0 && clientH > 0) {
            const f32 mx = minX + (static_cast<f32>(mouse.x) / static_cast<f32>(clientW)) * width;
            const f32 my = minY + (static_cast<f32>(mouse.y) / static_cast<f32>(clientH)) * height;
            const bool over = mx >= x0 && mx <= x0 + boxW && my >= y0 && my <= y0 + boxH;
            const bool leftDown = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
            const bool rightDown = (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
            const bool leftClicked = leftDown && !prevLeftDown;
            const bool rightClicked = rightDown && !prevRightDown;

            if (over && leftClicked) {
                s_dragging = true;
                s_dragOffsetX = mx - cx;
                s_dragOffsetY = my - cy;
            }
            if (!leftDown) s_dragging = false;

            if (s_dragging && svc_config != nullptr) {
                const f32 newCx = std::clamp(mx - s_dragOffsetX, minX, minX + width);
                const f32 newCy = std::clamp(my - s_dragOffsetY, minY, minY + height);
                const int64_t newXPct = static_cast<int64_t>(std::clamp((newCx - minX) * 100.0f / width, 0.0f, 100.0f));
                const int64_t newYPct = static_cast<int64_t>(std::clamp((newCy - minY) * 100.0f / height, 0.0f, 100.0f));
                svc_config->set_int(mod_ctx, s_x, newXPct);
                svc_config->set_int(mod_ctx, s_y, newYPct);
                cx = newCx;
                cy = newCy;
                x0 = std::clamp(cx - boxW * 0.5f, minX + 4.0f, minX + width - boxW - 4.0f);
                y0 = std::clamp(cy - boxH * 0.5f, minY + 4.0f, minY + height - boxH - 4.0f);
            }

            // Right-click hides the counter. Restore it from
            // Hyrule Online -> Show Hero Counter.
            if (over && rightClicked && svc_config != nullptr) {
                svc_config->set_bool(mod_ctx, s_enabled, false);
                s_dragging = false;
                prevLeftDown = leftDown;
                prevRightDown = rightDown;
                return;
            }
            prevLeftDown = leftDown;
            prevRightDown = rightDown;
        }
    }
#endif

    ortho.setColor(JUtility::TColor(12, 14, 20, alpha));
    ortho.fillBox(JGeometry::TBox2<f32>(x0, y0, x0 + boxW, y0 + boxH));
    ortho.setColor(JUtility::TColor(220, 188, 64, alpha));
    ortho.fillBox(JGeometry::TBox2<f32>(x0, y0, x0 + 4.0f * scale, y0 + boxH));

    font->setGX();
    const f32 tx = x0 + padX;
    const f32 ty = y0 + padY + cell * 0.85f;
    const f32 shadow = cell * 0.07f;
    font->setCharColor(JUtility::TColor(0, 0, 0, static_cast<u8>(alpha * 0.85f)));
    font->drawString_scale(tx + shadow, ty + shadow, cell, cell, line1.c_str(), true);
    font->drawString_scale(tx + shadow, ty + cell + shadow, cell, cell, line2.c_str(), true);
    font->setCharColor(JUtility::TColor(255, 255, 255, alpha));
    font->drawString_scale(tx, ty, cell, cell, line1.c_str(), true);
    font->drawString_scale(tx, ty + cell, cell, cell, line2.c_str(), true);
}

void draw_voice_overlay() {
    if (!s_hooked || !global_client_connected()) return;
    const auto lines = global_voice_overlay_lines();
    if (lines.empty()) return;
    JUTFont* font = mDoExt_getMesgFont();
    if (font == nullptr) return;

    const f32 minX = mDoGph_gInf_c::getMinXF();
    const f32 minY = mDoGph_gInf_c::getMinYF();
    const f32 width = mDoGph_gInf_c::getWidthF();
    const f32 height = mDoGph_gInf_c::getHeightF();
    J2DOrthoGraph ortho(0.0f, 0.0f, static_cast<f32>(FB_WIDTH), static_cast<f32>(FB_HEIGHT), -1.0f, 1.0f);
    ortho.setOrtho(minX, minY, width, height, -1.0f, 1.0f);
    ortho.setPort();

    const f32 cell = 14.0f;
    const f32 padX = 10.0f;
    const f32 padY = 7.0f;
    f32 textW = 0.0f;
    for (const auto& line : lines) textW = std::max(textW, coop_text_width(font, line.c_str(), cell));
    const f32 boxW = textW + padX * 2.0f;
    const f32 boxH = cell * static_cast<f32>(lines.size()) + padY * 2.0f;
    const f32 x0 = minX + 14.0f;
    const f32 y0 = std::clamp(minY + height * 0.23f, minY + 8.0f, minY + height - boxH - 8.0f);
    const u8 alpha = 205;

    ortho.setColor(JUtility::TColor(12, 14, 20, alpha));
    ortho.fillBox(JGeometry::TBox2<f32>(x0, y0, x0 + boxW, y0 + boxH));
    ortho.setColor(JUtility::TColor(220, 188, 64, alpha));
    ortho.fillBox(JGeometry::TBox2<f32>(x0, y0, x0 + 3.0f, y0 + boxH));

    font->setGX();
    for (size_t i = 0; i < lines.size(); ++i) {
        const f32 tx = x0 + padX;
        const f32 ty = y0 + padY + cell * (0.85f + static_cast<f32>(i));
        font->setCharColor(JUtility::TColor(0, 0, 0, 170));
        font->drawString_scale(tx + 1.0f, ty + 1.0f, cell, cell, lines[i].c_str(), true);
        font->setCharColor(JUtility::TColor(255, 255, 255, 245));
        font->drawString_scale(tx, ty, cell, cell, lines[i].c_str(), true);
    }
}

void on_draw_post(ModContext*, void*, void*, void*) {
    draw_hud();
    draw_voice_overlay();
}
}

void global_hud_init() {
    if (svc_config == nullptr) return;
    s_enabled = reg_bool("global_hud_enabled", true);
    s_x = reg_int("global_hud_x_pct", 50);
    s_y = reg_int("global_hud_y_pct", 8);
    s_size = reg_int("global_hud_size_pct", 75);
    s_opacity = reg_int("global_hud_opacity_pct", 82);
    s_hooked = mods::hook::add_post<GlobalHudDraw2DXluHook>(on_draw_post) == MOD_OK;
    coop_log::info("coop_mod: [GLOBAL HUD] {}", s_hooked ? "ready" : "2D hook failed");
}
ConfigVarHandle global_hud_enabled_var() { return s_enabled; }
ConfigVarHandle global_hud_x_var() { return s_x; }
ConfigVarHandle global_hud_y_var() { return s_y; }
ConfigVarHandle global_hud_size_var() { return s_size; }
ConfigVarHandle global_hud_opacity_var() { return s_opacity; }
void global_hud_center() {
    if (svc_config == nullptr) return;
    svc_config->set_int(mod_ctx, s_x, 50);
    svc_config->set_int(mod_ctx, s_y, 8);
    svc_config->set_int(mod_ctx, s_size, 75);
    svc_config->set_int(mod_ctx, s_opacity, 82);
}
