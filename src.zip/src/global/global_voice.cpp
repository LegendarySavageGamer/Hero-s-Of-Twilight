#include "global_voice.hpp"

#include "global_client.hpp"
#include "../voice_chat.hpp"
#include "../mod.hpp"
#include "../print.hpp"
#include "../util.hpp"

#include "d/actor/d_a_alink.h"
#include "d/d_com_inf_game.h"
#include "f_op/f_op_actor_mng.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <map>
#include <memory>
#include <string>

#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#endif

extern const ConfigService* svc_config;

namespace {
ConfigVarHandle s_enabledVar = 0;
ConfigVarHandle s_proximityVar = 0;
ConfigVarHandle s_rangeVar = 0;
ConfigVarHandle s_inputVar = 0;
ConfigVarHandle s_micVolumeVar = 0;
ConfigVarHandle s_playerVolumeVar = 0;
ConfigVarHandle s_mutedVar = 0;
ConfigVarHandle s_muteHotkeyVar = 0;
std::unique_ptr<heroes_voice::VoiceChat> s_voice;
std::string s_status = "Voice Chat is off.";
bool s_hotkeyCapture = false;
bool s_hotkeyWasDown = false;
using Clock = std::chrono::steady_clock;
Clock::time_point s_localSpeakingUntil{};
struct RemoteSpeaker {
    std::string name;
    Clock::time_point until{};
};
std::map<uint64_t, RemoteSpeaker> s_remoteSpeaking;

ConfigVarHandle reg_bool(const char* name, bool fallback) {
    ConfigVarDesc d = CONFIG_VAR_DESC_INIT;
    d.name = name; d.type = CONFIG_VAR_BOOL; d.default_bool = fallback;
    ConfigVarHandle h = 0; svc_config->register_var(mod_ctx, &d, &h); return h;
}
ConfigVarHandle reg_int(const char* name, int64_t fallback) {
    ConfigVarDesc d = CONFIG_VAR_DESC_INIT;
    d.name = name; d.type = CONFIG_VAR_INT; d.default_int = fallback;
    ConfigVarHandle h = 0; svc_config->register_var(mod_ctx, &d, &h); return h;
}
ConfigVarHandle reg_string(const char* name, const char* fallback) {
    ConfigVarDesc d = CONFIG_VAR_DESC_INIT;
    d.name = name; d.type = CONFIG_VAR_STRING; d.default_string = fallback;
    ConfigVarHandle h = 0; svc_config->register_var(mod_ctx, &d, &h); return h;
}

bool voice_enabled() { return cfg_bool(s_enabledVar, false); }
bool proximity_enabled() { return cfg_bool(s_proximityVar, true); }
bool mic_muted() { return cfg_bool(s_mutedVar, false); }
int range_percent() { return static_cast<int>(std::clamp<int64_t>(cfg_int(s_rangeVar, 50), 0, 200)); }
int mic_volume() { return static_cast<int>(std::clamp<int64_t>(cfg_int(s_micVolumeVar, 100), 0, 200)); }
int player_volume() { return static_cast<int>(std::clamp<int64_t>(cfg_int(s_playerVolumeVar, 100), 0, 200)); }

std::string capture_device() {
    std::string input = cfg_string(s_inputVar, "Default Microphone");
    if (input == "Default Microphone") input.clear();
    return input;
}

float proximity_gain(uint64_t globalId) {
    if (!proximity_enabled()) return 1.0f;
    GlobalVoicePeerState peer;
    if (!global_client_voice_peer_state(globalId, peer) || !peer.valid) return 0.0f;
    daAlink_c* me = daAlink_getAlinkActorClass();
    const char* stage = dComIfGp_getStartStageName();
    if (me == nullptr || stage == nullptr || stage[0] == '\0' ||
        std::strncmp(peer.stage, stage, 8) != 0) return 0.0f;
    const int localRoom = fopAcM_GetRoomNo(me);
    // Heroes adds the room safety gate requested for Hyrule Online. MFB's
    // distance curve itself is preserved below.
    if (peer.room < 0 || peer.room != localRoom) return 0.0f;
    if (!std::isfinite(peer.x) || !std::isfinite(peer.y) || !std::isfinite(peer.z) ||
        !std::isfinite(me->current.pos.x) || !std::isfinite(me->current.pos.y) ||
        !std::isfinite(me->current.pos.z)) return 0.0f;
    const float dx = peer.x - me->current.pos.x;
    const float dy = peer.y - me->current.pos.y;
    const float dz = peer.z - me->current.pos.z;
    const float distance = std::sqrt(dx * dx + dy * dy + dz * dz);

    // Exact MFB range behavior: 0..200%, with 50% == 4000 game units.
    const float rangeScale = static_cast<float>(range_percent()) / 50.0f;
    if (rangeScale <= 0.0f) return 0.0f;
    const float fadeDistance = 4000.0f * rangeScale;
    const float tailDistance = 500.0f * rangeScale;
    if (distance >= fadeDistance) return 0.0f;
    const float attenuation = std::exp2(-6.0f * distance / fadeDistance);
    const float tail = std::min(1.0f, (fadeDistance - distance) / tailDistance);
    return attenuation * tail;
}

#if defined(_WIN32)
bool key_down(int vk) {
    return vk > 0 && vk < 256 && (GetAsyncKeyState(vk) & 0x8000) != 0;
}

bool capture_hotkey_if_requested() {
    if (!s_hotkeyCapture || svc_config == nullptr) return false;
    for (int vk = 8; vk < 255; ++vk) {
        // Ignore mouse buttons while the user is choosing a keyboard mute key.
        if (vk >= VK_LBUTTON && vk <= VK_XBUTTON2) continue;
        if (key_down(vk)) {
            svc_config->set_int(mod_ctx, s_muteHotkeyVar, vk);
            s_hotkeyCapture = false;
            s_hotkeyWasDown = true;
            return true;
        }
    }
    return false;
}
#endif

void update_mute_hotkey() {
#if defined(_WIN32)
    if (capture_hotkey_if_requested()) return;
    const int vk = static_cast<int>(std::clamp<int64_t>(cfg_int(s_muteHotkeyVar, 'M'), 1, 254));
    const bool down = key_down(vk);
    if (voice_enabled() && down && !s_hotkeyWasDown && svc_config != nullptr) {
        svc_config->set_bool(mod_ctx, s_mutedVar, !mic_muted());
    }
    s_hotkeyWasDown = down;
#endif
}

std::string vk_name(int vk) {
#if defined(_WIN32)
    UINT scan = MapVirtualKeyA(static_cast<UINT>(vk), MAPVK_VK_TO_VSC);
    LONG lparam = static_cast<LONG>(scan << 16);
    if (vk == VK_LEFT || vk == VK_UP || vk == VK_RIGHT || vk == VK_DOWN ||
        vk == VK_PRIOR || vk == VK_NEXT || vk == VK_END || vk == VK_HOME ||
        vk == VK_INSERT || vk == VK_DELETE || vk == VK_DIVIDE || vk == VK_NUMLOCK) {
        lparam |= 1 << 24;
    }
    char name[64] = {};
    if (GetKeyNameTextA(lparam, name, static_cast<int>(sizeof(name))) > 0) return name;
    if (vk >= 'A' && vk <= 'Z') return std::string(1, static_cast<char>(vk));
    if (vk >= '0' && vk <= '9') return std::string(1, static_cast<char>(vk));
#endif
    return "Key " + std::to_string(vk);
}
}

void global_voice_init() {
    if (svc_config != nullptr) {
        if (s_enabledVar == 0) s_enabledVar = reg_bool("global_voice_enabled", false);
        if (s_proximityVar == 0) s_proximityVar = reg_bool("global_voice_proximity", true);
        if (s_rangeVar == 0) s_rangeVar = reg_int("global_voice_proximity_range", 50);
        if (s_inputVar == 0) s_inputVar = reg_string("global_voice_input", "Default Microphone");
        if (s_micVolumeVar == 0) s_micVolumeVar = reg_int("global_voice_mic_volume", 100);
        if (s_playerVolumeVar == 0) s_playerVolumeVar = reg_int("global_voice_player_volume", 100);
        if (s_mutedVar == 0) s_mutedVar = reg_bool("global_voice_muted", false);
        if (s_muteHotkeyVar == 0) s_muteHotkeyVar = reg_int("global_voice_mute_hotkey", 'M');
    }
    if (!s_voice) s_voice = std::make_unique<heroes_voice::VoiceChat>();
    s_status = "Voice Chat is off.";
}

void global_voice_update() {
    if (!s_voice) return;
    update_mute_hotkey();
    const bool enabled = voice_enabled() && global_client_connected();
    s_voice->configure(enabled, mic_muted(), capture_device(), mic_volume(), player_volume(), false, 1.0f);
    if (!enabled) {
        s_status = voice_enabled() ? "Voice Chat is waiting for Hyrule Online." : "Voice Chat is off.";
        s_localSpeakingUntil = {};
        s_remoteSpeaking.clear();
        return;
    }

    const std::string& error = s_voice->error();
    if (!error.empty()) {
        s_status = "Voice Chat: " + error;
        return;
    }

    s_status = mic_muted() ? "Voice Chat is on - microphone muted." :
        (proximity_enabled() ? "Voice Chat is on - Proximity Mode active." : "Voice Chat is on.");

    const auto now = Clock::now();
    for (const auto& frame : s_voice->capture()) {
        if (frame.bytes.empty()) continue;
        if (frame.speaking) s_localSpeakingUntil = now + std::chrono::milliseconds(450);
        (void)global_client_send_voice(frame.sequence, frame.speaking, frame.bytes);
    }
    for (auto it = s_remoteSpeaking.begin(); it != s_remoteSpeaking.end();) {
        if (it->second.until <= now) it = s_remoteSpeaking.erase(it); else ++it;
    }
}

void global_voice_receive(uint64_t globalId, uint8_t slot, uint32_t sequence,
                          bool speaking, std::span<const uint8_t> opus) {
    if (!s_voice || !voice_enabled() || !global_client_connected() ||
        globalId == 0 || slot == 0 || sequence == 0 || opus.empty()) return;
    const float gain = proximity_gain(globalId);
    s_voice->receive(std::to_string(globalId), sequence, opus, gain, 0.5f);
    if (speaking && gain > 0.01f && player_volume() > 0) {
        std::string name = global_client_player_name(globalId);
        if (name.empty()) name = features_peer_name(slot);
        if (name.empty()) name = "Hero";
        s_remoteSpeaking[globalId] = {std::move(name), Clock::now() + std::chrono::milliseconds(550)};
    } else if (gain <= 0.01f) {
        s_remoteSpeaking.erase(globalId);
    }
}

void global_voice_peer_left(uint64_t globalId) {
    if (s_voice && globalId != 0) s_voice->peer_left(std::to_string(globalId));
    s_remoteSpeaking.erase(globalId);
}

void global_voice_shutdown() {
    if (s_voice) s_voice->stop();
    s_voice.reset();
    s_remoteSpeaking.clear();
    s_localSpeakingUntil = {};
    s_status = "Voice Chat is off.";
}

ConfigVarHandle global_voice_enabled_var() { return s_enabledVar; }
ConfigVarHandle global_voice_proximity_var() { return s_proximityVar; }
ConfigVarHandle global_voice_range_var() { return s_rangeVar; }
ConfigVarHandle global_voice_input_var() { return s_inputVar; }
ConfigVarHandle global_voice_mic_volume_var() { return s_micVolumeVar; }
ConfigVarHandle global_voice_player_volume_var() { return s_playerVolumeVar; }
ConfigVarHandle global_voice_muted_var() { return s_mutedVar; }
ConfigVarHandle global_voice_mute_hotkey_var() { return s_muteHotkeyVar; }

std::vector<std::string> global_voice_input_devices() {
    std::vector<std::string> out{"Default Microphone"};
    if (!s_voice) return out;
    for (auto& name : s_voice->input_devices()) {
        if (!name.empty() && name != "Default Microphone") out.push_back(std::move(name));
    }
    return out;
}

std::string global_voice_status() { return s_status; }
std::string global_voice_hotkey_name() {
    return vk_name(static_cast<int>(cfg_int(s_muteHotkeyVar, 'M')));
}
void global_voice_begin_hotkey_capture() { s_hotkeyCapture = true; s_hotkeyWasDown = false; }
bool global_voice_hotkey_capture_active() { return s_hotkeyCapture; }

std::vector<std::string> global_voice_overlay_lines() {
    std::vector<std::string> lines;
    if (!voice_enabled() || !global_client_connected()) return lines;
    const auto now = Clock::now();
    if (mic_muted()) lines.emplace_back("[MUTED] Mic Muted");
    if (!mic_muted() && s_localSpeakingUntil > now) {
        lines.emplace_back("[MIC] " + global_client_local_name());
    }
    for (const auto& [id, speaker] : s_remoteSpeaking) {
        (void)id;
        if (speaker.until > now) lines.emplace_back("[VOICE] " + speaker.name);
    }
    return lines;
}
