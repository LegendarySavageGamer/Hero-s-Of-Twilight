#pragma once
#include "mods/svc/config.h"

void global_hud_init();
ConfigVarHandle global_hud_enabled_var();
ConfigVarHandle global_hud_x_var();
ConfigVarHandle global_hud_y_var();
ConfigVarHandle global_hud_size_var();
ConfigVarHandle global_hud_opacity_var();
void global_hud_center();
